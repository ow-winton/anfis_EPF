"""
包含模型构建流程
"""
from etide.utils import get_date
import logging
logger = logging.getLogger(__name__)


class ModelBase:
    """
    模型基类模板
    all functions should be implemented by real model class.
    Parameters
    ----------
    name : str
        model name
        unique in models package.

    """
    def __init__(self,
                 name,
                 feature_list,
                 target,
                 delay_days=0,
                 max_back_days=None,
                 pred_min=None,
                 pred_max=None,
                 pred_feature_dict=None
                 ):
        """
        初始化参数配置
        :param name: 模型名称，数据类型为str
        :param feature_list: 指定特征列表，数据类型为str list
        :param target: 指定预测目标列，数据类型为str
        :param delay_days: 指定模型训练时能获取的最新训练数据的延时天数，数据类型为int
        :param max_back_days: 指定模型训练时采用历史数据的长度，数据类型为int或者None，为None则表示用全量数据训练
        :param pred_min: 设置模型预测结果最小值，数据类型为int或者None，为None则表示不限制预测结果下限
        :param pred_max: 设置模型预测结果最大值，数据类型为int或者None，为None则表示不限制预测结果上限
        :param pred_feature_dict: 预测时所需字段与训练字段映射，若为None则默认预测时所有字段与训练时一致，数据类型为dict
        """
        self.name = name
        self.feature_list = feature_list
        self.target = target
        self.delay_days = delay_days
        self.max_back_days = max_back_days
        self.pred_min = pred_min
        self.pred_max = pred_max
        self.pred_feature_dict = pred_feature_dict
        self.model = None

    def set_model_params(self, params):
        for param_name in params:
            if param_name not in self.__dict__:
                logger.warning('模型参数{param_name}不存在，模型新增该参数')
            self.__dict__[param_name] = params[param_name]

    def generate_pred_feature_list(self):
        pred_feature_list = self.feature_list.copy()
        if self.pred_feature_dict is not None:
            for f in self.feature_list:
                if f in self.pred_feature_dict:
                    pred_feature_list[pred_feature_list.index(f)] = self.pred_feature_dict[f]
                else:
                    continue
        return pred_feature_list

    def get_train_data(self, data, pred_date):
        """
        获取训练数据
        :param data: 输入数据，数据类型为dataframe，包含所有特征列和目标列，index为时间戳类型
        :param pred_date: 预测日期，数据类型为str，格式为%Y-%m-%d
        Returns: 筛选样本函数，统一api
        """
        # 选取训练样本集合
        if self.max_back_days is not None:
            sta_date = get_date(pred_date, shift_days=-self.max_back_days)
            data = data.loc[sta_date:]
        end_date = get_date(pred_date, shift_days=-self.delay_days)
        df_hist = data.loc[:end_date]
        """
        implement your customized training data selection function here
        df_train = select_training_data()
        """
        df_train = df_hist.dropna(subset=self.feature_list+[self.target])
        train_feature = df_train[self.feature_list]
        train_target = df_train[self.target]
        return train_feature, train_target

    def get_pred_data(self, data, pred_date):
        """
        获取预测数据
        :param data: 输入数据，数据类型为dataframe，包含所有特征列和目标列，index为时间戳类型
        :param pred_date: 预测日期，数据类型为str，格式为%Y-%m-%d
        """
        pred_feature_list = self.generate_pred_feature_list()
        pred_feature = data.loc[pred_date, pred_feature_list]
        if pred_feature.isna().any().any():
            nan_cols = pred_feature.columns[pred_feature.isna().any()]
            logger.warning(f'there is NaN in input predicting features:{nan_cols}')
        """
        implement your customized prediction feature/sample generation function here
        pred_feature = generate_pred_feature()
        """
        return pred_feature

    def build(self):
        """
        build model.
        """
        raise Exception('must implement "%s" by subclass' % self.build.__name__)

    def fit(self, X_train, y_train):
        """
        train model

        Parameters
        -------
        :param X_train: 训练特征数据，数据类型为Dataframe，包含所有特征列
        :param y_train: 训练目标数据，数据类型为Series，包含预测列
        :Returns: model， the trained model
        """
        raise Exception('must implement "%s" by subclass' % self.fit.__name__)

    def predict(self, X_test):
        """
        predict target values

        Parameters
        -------
        :param X_test: 预测数据，数据类型为Dataframe，包含所有预测特征列
        Returns
        -------
        Dataframe或者Series
            predicted values
        """
        raise Exception('must implement "%s" by subclass' % self.predict.__name__)

    def run(self, data, test_date):
        """
        run model pipeline including training and predicting
        from the beginning for the specified test date
        :param data: 输入数据，数据类型为dataframe，包含所需的训练数据和预测数据，index为时间戳类型
        :param test_date: 测试日期，数据类型为str，格式为%Y-%m-%d
        :return: 模型预测结果，数据类型为Dataframe或者Series，index为时间戳类型
        """
        train_feature, train_target = self.get_train_data(data, test_date)
        self.fit(train_feature, train_target)
        pred_feature = self.get_pred_data(data, test_date)
        prediction_result = self.predict(pred_feature)
        return prediction_result
