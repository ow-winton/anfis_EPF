"""
包含精度指标计算及模型评估功能
"""

import pandas as pd
import numpy as np


def load_accuracy_mape(y_true, y_pred):
    """
    计算负荷预测曲线1-MAPE精度
    :param y_true: 负荷真值，series或者ndarray
    :param y_pred: 负荷预测值，series或者ndarray，预测值和真值长度必须相等
    :return:
    """
    y_true = pd.Series(y_true).copy()
    y_pred = pd.Series(y_pred).copy()
    if len(y_true) > 0 and (y_true.index == y_pred.index).all():
        mask = y_true.notna() & y_pred.notna()
        y_true = y_true[mask]
        y_pred = y_pred[mask]

        epsilon = np.finfo(np.float64).eps
        mape = (y_pred - y_true).abs() / np.maximum(y_true.abs(), epsilon)
        mape = mape.dropna()
        mape[mape >= 1] = 1
        return 1 - mape.mean()
    else:
        return np.nan


def load_accuracy_mae(y_true, y_pred):
    """
    计算负荷预测曲线MAE
    :param y_true: 负荷真值，series或者ndarray
    :param y_pred: 负荷预测值，series或者ndarray，预测值和真值长度必须相等
    :return:
    """
    y_true = pd.Series(y_true).copy()
    y_pred = pd.Series(y_pred).copy()
    if len(y_true) > 0 and (y_true.index == y_pred.index).all():
        mask = y_true.notna() & y_pred.notna()
        y_true = y_true[mask]
        y_pred = y_pred[mask]
        mae = (y_pred - y_true).abs()
        return mae.mean()
    else:
        return np.nan


def price_accuracy_smape(y_true, y_pred, cutoff=55):
    """
    计算预测曲线值准确率
    :param y_true: 电价真值，series或者ndarray
    :param y_pred: 电价预测值，series或者ndarray，预测值和真值长度必须相等
    :param cutoff: 真值和预测值在截断值以下取值为截断值
    :return:
    """
    y_true = pd.Series(y_true).copy()
    y_pred = pd.Series(y_pred).copy()
    if len(y_true) > 0 and (y_true.index == y_pred.index).all():
        mask = y_true.notna() & y_pred.notna()
        y_true = y_true[mask]
        y_pred = y_pred[mask]
        # 低价截断
        y_true[y_true <= cutoff] = cutoff
        y_pred[y_pred <= cutoff] = cutoff

        epsilon = np.finfo(np.float64).eps
        baseline = (y_true.abs() + y_pred.abs()) / 2
        baseline[baseline < epsilon] = epsilon
        smape = (y_true - y_pred).abs() / baseline
        smape = smape.dropna()
        smape[smape >= 1] = 1
        return 1 - smape.mean()
    else:
        return np.nan


def price_accuracy_spic_shandong(y_true, y_pred):
    """
    计算SPIC中央研究院电价预测曲线值准确率指标
    :param y_true: 电价真值，series或者ndarray
    :param y_pred: 电价预测值，series或者ndarray，预测值和真值长度必须相等
    :return:
    """
    accuracy = np.nan
    y_true = pd.Series(y_true).copy()
    y_pred = pd.Series(y_pred).copy()
    if len(y_true) > 0 and (y_true.index == y_pred.index).all():
        mask = y_true.notna() & y_pred.notna()
        y_true = y_true[mask]
        y_pred = y_pred[mask]
        y_true[(y_true > 0) & (y_true < 50)] = 50
        y_pred[(y_true > 0) & (y_pred < 50)] = 50
        accuracy = 1 - (y_true - y_pred).abs() / y_true
        accuracy[(y_true <= 0) & (y_pred <= 0)] = 1
        accuracy[(y_true <= 0) & (y_pred > 0)] = 0
        accuracy[accuracy < 0] = 0
        accuracy = accuracy.mean()
    return accuracy


def price_accuracy_spic_shanxi(y_true, y_pred, cut_off=80):
    """
    计算山西SPIC中央研究院电价预测曲线值准确率指标
    :param y_true: 电价真值，series或者ndarray
    :param y_pred: 电价预测值，series或者ndarray，预测值和真值长度必须相等
    :param cut_off: 真值和预测值在截断值以下取值为截断值
    :return:
    """
    accuracy = np.nan
    y_true = pd.Series(y_true).copy()
    y_pred = pd.Series(y_pred).copy()
    if len(y_true) > 0 and (y_true.index == y_pred.index).all():
        mask = y_true.notna() & y_pred.notna()
        y_true = y_true[mask]
        y_pred = y_pred[mask]
        # 低价截断
        y_true[y_true <= cut_off] = cut_off
        y_pred[y_pred <= cut_off] = cut_off

        y_true, pred = np.array(y_true), np.array(y_pred)
        error = np.abs((y_true - pred) / y_true)
        error = np.clip(error, a_min=0, a_max=1)
        error[(y_true == 0) & (pred == 0)] = 0
        accuracy = 1 - np.mean(error)
    return accuracy


def price_diff_weighted_accuracy(y_true, y_pred, resample_by_hour=True):
    """
    计算价差加权准确率指标
    :param y_true: 价差真值，series或者ndarray
    :param y_pred: 价差预测值，series或者ndarray，预测值和真值长度必须相等
    :param resample_by_hour: 是否将15min曲线重采样成1h曲线
    :return:
    """
    accuracy = np.nan
    y_true = pd.Series(y_true).copy()
    y_pred = pd.Series(y_pred).copy()
    if len(y_true) > 0 and (y_true.index == y_pred.index).all():
        if resample_by_hour:
            y_true = y_true.reset_index(drop=True)
            y_pred = y_pred.reset_index(drop=True)
            y_true = y_true.groupby(y_true.index // 4).mean()
            y_pred = y_pred.groupby(y_pred.index // 4).mean()
        mask = y_true.notna() & y_pred.notna()
        y_true = y_true[mask]
        y_pred = y_pred[mask]
        baseline = y_true.abs().sum()
        if baseline > 0:
            accuracy = y_true[(y_true * y_pred) > 0].abs().sum() / baseline
    return accuracy


def price_peak_valley_accuracy(y_true, y_pred, eval_num=8):
    """
    计算预测曲线峰谷准确率
    :param y_true: 电价真值，series或者ndarray
    :param y_pred: 电价预测值，series或者ndarray，预测值和真值长度必须相等
    :param eval_num: 评估点数
    :return:
    """
    y_true = pd.Series(y_true).copy()
    y_pred = pd.Series(y_pred).copy()
    if len(y_true) > 0 and (y_true.index == y_pred.index).all():
        mask = y_true.notna() & y_pred.notna()
        y_true = y_true[mask]
        y_pred = y_pred[mask]
        spread = []
        m = []
        for day, y_true_day in y_true.resample('D'):
            # 真值峰谷差
            peak_day = y_true_day.nlargest(n=eval_num, keep='first')
            valley_day = y_true_day.nsmallest(n=eval_num, keep='first')
            spread_day = np.sum(peak_day.values - valley_day.values)
            # 预测峰谷
            y_pred_day = y_pred.loc[y_true_day.index]
            peak_pred_day = y_pred_day.nlargest(n=eval_num, keep='first')
            valley_pred_day = y_pred_day.nsmallest(n=eval_num, keep='first')
            spread_pred_day = np.sum(y_true_day.loc[peak_pred_day.index].values -
                                 y_true_day.loc[valley_pred_day.index].values)
            m_day = spread_pred_day / np.maximum(np.abs(spread_day), np.finfo(np.float64).eps)
            spread.append(spread_day)
            m.append(m_day)
        spread = pd.Series(spread)
        m = pd.Series(m)
        result = (m * spread).sum() / spread.sum()
        return result
    else:
        return np.nan


def price_mae_accuracy(y_true, y_pred, cut_off_max=None, cut_off_min=None):
    """
    计算电价预测MAE准确率指标
    :param y_true: 电价真值，series或者ndarray
    :param y_pred: 电价预测值，series或者ndarray，预测值和真值长度必须相等
    :param cut_off_max: 真值和预测值在截断值以上取值为截断值
    :param cut_off_min: 真值和预测值在截断值以下取值为截断值
    :return:
    """
    y_true = pd.Series(y_true).copy()
    y_pred = pd.Series(y_pred).copy()
    y_true = np.clip(y_true, a_max=cut_off_max, a_min=cut_off_min)
    y_pred = np.clip(y_pred, a_max=cut_off_max, a_min=cut_off_min)
    result = (y_true - y_pred).abs().mean()
    return result


def price_longterm_weighted_accuracy(spot_price, longterm_price, price_prediction):
    """
    计算中长期电价预测加权准确率指标
    :param spot_price: 现货电价真值，series或者ndarray
    :param longterm_price: 中长期成交电价，series或者ndarray
    :param price_prediction: 现货电价预测值，series或者ndarray
    :return:
    """
    accuracy = np.nan
    spot_price = pd.Series(spot_price).copy()
    longterm_price = pd.Series(longterm_price).copy()
    price_prediction = pd.Series(price_prediction).copy()
    if len(spot_price) > 0 and (spot_price.index == longterm_price.index).all() \
        and (spot_price.index == price_prediction.index).all():
        spot_longterm_price_diff = spot_price - longterm_price
        prediction_longterm_price_diff = price_prediction - longterm_price
        mask = spot_longterm_price_diff * prediction_longterm_price_diff > 0
        accuracy = spot_longterm_price_diff[mask].abs().sum() / spot_longterm_price_diff.abs().sum()
    return accuracy


def daily_metric(df, metric_dict, target_name, pred_name):
    """
    计算各个metric 并合并为DataFrame的形式 分别为均值与每天准确率值
    :param df: 包含真值与预测列的DataFrame，index为时间戳
    :param metric_dict: 指标计算具体函数dict，key为该指标名称，value为func
    :param target_name: target name，string
    :param pred_name: pred name，list or string
    :return: 以天为单位的各个指标计算值，以及均值
    """
    df = df.copy()
    mean_acc, daily_acc = [], []
    if type(pred_name) is not list:

        for metric, func in metric_dict.items():
            r = df.resample('D').apply(lambda x: func(x[target_name], x[pred_name]))
            daily_acc.append(pd.DataFrame(r, columns=[pred_name + '_' + metric]))
            mean_acc.append(pd.DataFrame({metric: r.mean()}, index=[pred_name]))
        mean_acc = pd.concat(mean_acc, axis=1)
    else:
        for n in pred_name:
            daily_acc_n, mean_acc_n = [], []
            for metric, func in metric_dict.items():
                r = df.resample('D').apply(lambda x: func(x[target_name], x[n]))
                daily_acc_n.append(pd.DataFrame(r, columns=[n + '_' + metric]))
                mean_acc_n.append(pd.DataFrame({metric: r.mean()}, index=[n]))
            daily_acc.append(pd.concat(daily_acc_n, axis=1))
            mean_acc.append(pd.concat(mean_acc_n, axis=1))
        mean_acc = pd.concat(mean_acc, axis=0)
    daily_acc = pd.concat(daily_acc, axis=1)
    return mean_acc, daily_acc


def monthly_metric(df, metric_dict, target_name, pred_name):
    """
    计算各个metric 并合并为DataFrame的形式 分别为均值与每月准确率值
    :param df: 包含真值与预测列的DataFrame，index为时间戳
    :param metric_dict: 指标计算具体函数dict，key为该指标名称，value为func
    :param target_name: target name，string
    :param pred_name: pred name，list or string
    :return: 以月为单位的各个指标计算值，以及均值
    """
    df = df.copy()
    mean_acc, monthly_acc = [], []
    if type(pred_name) is not list:

        for metric, func in metric_dict.items():
            r = df.resample('M').apply(lambda x: func(x[target_name], x[pred_name]))
            monthly_acc.append(pd.DataFrame(r, columns=[pred_name + '_' + metric]))
            mean_acc.append(pd.DataFrame({metric: r.mean()}, index=[pred_name]))
        mean_acc = pd.concat(mean_acc, axis=1)
    else:
        for n in pred_name:
            monthly_acc_n, mean_acc_n = [], []
            for metric, func in metric_dict.items():
                r = df.resample('M').apply(lambda x: func(x[target_name], x[n]))
                monthly_acc_n.append(pd.DataFrame(r, columns=[n + '_' + metric]))
                mean_acc_n.append(pd.DataFrame({metric: r.mean()}, index=[n]))
            monthly_acc.append(pd.concat(monthly_acc_n, axis=1))
            mean_acc.append(pd.concat(mean_acc_n, axis=1))
        mean_acc = pd.concat(mean_acc, axis=0)
    monthly_acc = pd.concat(monthly_acc, axis=1)
    return mean_acc, monthly_acc


def average_metric(df, metric_dict, target_name, pred_name):
    """
    将输入时段数据按照整体计算各个metric均值 并合并为DataFrame的形式
    :param df: 包含真值与预测列的DataFrame，index为时间戳
    :param metric_dict: 指标计算具体函数dict，key为该指标名称，value为func
    :param target_name: target name，string
    :param pred_name: pred name，list or string
    :return: 各个指标均值
    """
    df = df.copy()
    mean_acc = []
    if type(pred_name) is not list:

        for metric, func in metric_dict.items():
            r = func(df[target_name], df[pred_name])
            mean_acc.append(pd.DataFrame({metric: r}, index=[pred_name]))
        mean_acc = pd.concat(mean_acc, axis=1)
    else:
        for n in pred_name:
            mean_acc_n = []
            for metric, func in metric_dict.items():
                r = func(df[target_name], df[n])
                mean_acc_n.append(pd.DataFrame({metric: r}, index=[n]))
            mean_acc.append(pd.concat(mean_acc_n, axis=1))
        mean_acc = pd.concat(mean_acc, axis=0)
    return mean_acc

