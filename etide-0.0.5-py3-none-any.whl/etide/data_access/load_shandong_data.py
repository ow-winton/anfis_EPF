from poseidon import poseidon
import pandas as pd
import time
from datetime import datetime
import pytz
import etide.config

province_code = 37
node = 'xiJiao'

columns_gx = ['loadRegulation', 'tieLineLoad', 'wind', 'solar',
              'localPowerPlant', 'testUnit', 'standByUnit', 'pumpedStoragePower']
columns_price = ['daClearingPriceBeforeReduce', 'rtClearingPriceBeforeReduce']
columns_map = {
    'daClearingPriceBeforeReduce': '日前_电价(元/MWh)',
    'rtClearingPriceBeforeReduce': '实时_电价(元/MWh)',
    'dayahead_loadRegulation': '出清前_直调负荷(MW)',
    'dayahead_localPowerPlant': '出清前_地方电厂发电总加(MW)',
    'dayahead_tieLineLoad': '出清前_联络线受电负荷(MW)',
    'dayahead_wind': '出清前_风电总加(MW)',
    'dayahead_solar': '出清前_光伏总加(MW)',
    'dayahead_testUnit': '出清前_试验机组总加(MW)',
    'dayahead_standByUnit': '出清前_自备机组总加(MW)',
    'dayahead_pumpedStoragePower': '出清前_抽蓄(MW)',
    'dayahead_clear_loadRegulation': '出清后_直调负荷(MW)',
    'dayahead_clear_tieLineLoad': '出清后_联络线受电负荷(MW)',
    'dayahead_clear_wind': '出清后_风电总加(MW)',
    'dayahead_clear_solar': '出清后_光伏总加(MW)',
    'intraday_loadRegulation': '实时_直调负荷(MW)',
    'intraday_localPowerPlant': '实时_地方电厂发电总加(MW)',
    'intraday_tieLineLoad': '实时_联络线受电负荷(MW)',
    'intraday_wind': '实时_风电总加(MW)',
    'intraday_solar': '实时_光伏总加(MW)',
    'intraday_pumpedStoragePower': '实时_抽蓄(MW)',
    'daClearingPriceBeforeReduce_d1': '远景预测日前电价(元/MWh)',
    'rtClearingPriceBeforeReduce_d1': '远景预测实时电价(元/MWh)',
    'daClearingPriceBeforeReduce_d2': '日前电价预测D+2',
    'daClearingPriceBeforeReduce_d3': '日前电价预测D+3',
    'daClearingPriceBeforeReduce_d4': '日前电价预测D+4',
    'daClearingPriceBeforeReduce_d5': '日前电价预测D+5',
    'daClearingPriceBeforeReduce_d6': '日前电价预测D+6',
    'daClearingPriceBeforeReduce_d7': '日前电价预测D+7',
    'daClearingPriceBeforeReduce_d8': '日前电价预测D+8',
    'daClearingPriceBeforeReduce_d9': '日前电价预测D+9',
    'loadRegulation_d2': '出清前_直调负荷(MW)_d2',
    'tieLineLoad_d2': '出清前_联络线受电负荷(MW)_d2',
    'wind_d2': '出清前_风电总加(MW)_d2',
    'solar_d2': '出清前_光伏总加(MW)_d2',
    'loadRegulation_d3': '出清前_直调负荷(MW)_d3',
    'tieLineLoad_d3': '出清前_联络线受电负荷(MW)_d3',
    'wind_d3': '出清前_风电总加(MW)_d3',
    'solar_d3': '出清前_光伏总加(MW)_d3',
    'loadRegulation_d4': '出清前_直调负荷(MW)_d4',
    'tieLineLoad_d4': '出清前_联络线受电负荷(MW)_d4',
    'wind_d4': '出清前_风电总加(MW)_d4',
    'solar_d4': '出清前_光伏总加(MW)_d4',
    'loadRegulation_d5': '出清前_直调负荷(MW)_d5',
    'tieLineLoad_d5': '出清前_联络线受电负荷(MW)_d5',
    'wind_d5': '出清前_风电总加(MW)_d5',
    'solar_d5': '出清前_光伏总加(MW)_d5',
    'loadRegulation_d6': '出清前_直调负荷(MW)_d6',
    'tieLineLoad_d6': '出清前_联络线受电负荷(MW)_d6',
    'wind_d6': '出清前_风电总加(MW)_d6',
    'solar_d6': '出清前_光伏总加(MW)_d6',
    'loadRegulation_d7': '出清前_直调负荷(MW)_d7',
    'tieLineLoad_d7': '出清前_联络线受电负荷(MW)_d7',
    'wind_d7': '出清前_风电总加(MW)_d7',
    'solar_d7': '出清前_光伏总加(MW)_d7',
    'loadRegulation_d8': '出清前_直调负荷(MW)_d8',
    'tieLineLoad_d8': '出清前_联络线受电负荷(MW)_d8',
    'wind_d8': '出清前_风电总加(MW)_d8',
    'solar_d8': '出清前_光伏总加(MW)_d8',
    'loadRegulation_d9': '出清前_直调负荷(MW)_d9',
    'tieLineLoad_d9': '出清前_联络线受电负荷(MW)_d9',
    'wind_d9': '出清前_风电总加(MW)_d9',
    'solar_d9': '出清前_光伏总加(MW)_d9'
}


def read_config():
    daas_url = etide.config.CONFIG_PARAM['daas_domain_name']
    accesskey = etide.config.CONFIG_PARAM['daas_access_key']
    secretkey = etide.config.CONFIG_PARAM['daas_secret_key']
    return daas_url, accesskey, secretkey


def get_shandong_gx(start_date, end_date=None):
    daas_url, accesskey, secretkey = read_config()
    start_time = start_date + ' 00:15:00'
    if end_date is None:
        end_time = str(pd.Timestamp(start_time) + pd.Timedelta(1, 'D'))
    else:
        end_time = str(pd.Timestamp(end_date + ' 00:15:00') + pd.Timedelta(1, 'D'))
    url_gx = f'https://{daas_url}/trading-terminal-api/v1/center-base/net/' \
             f'suppl-demand?provinceCode={province_code}' \
             f'&siteId=&publishDay=&tradeDay=&startTime={start_time}&endTime={end_time}'
    url_gx = url_gx.replace(" ", "%20")
    t = time.time()
    r = poseidon.urlopen(accesskey, secretkey, url_gx, timeout=100)
    print('gx time:', time.time() - t)
    data = pd.DataFrame(r['data'])
    data['publishDay'] = pd.to_datetime(data['publishDay'])
    data['tradeTime'] = data['tradeTime'].apply(lambda x: str(pd.Timestamp(x[:10]) + pd.Timedelta(1, 'D'))
    if x[-8:] == '24:00:00' else x)
    data['tradeTime'] = pd.to_datetime(data['tradeTime']) - pd.Timedelta(15, 'min')
    data['deltaDay'] = (data['tradeTime'] - data['publishDay']).apply(lambda x: x.days)
    data_dayahead = data[data['deltaDay'] == 1].set_index('tradeTime').sort_index()
    data_dayahead_clear = data[data['deltaDay'] == 0].set_index('tradeTime').sort_index()
    data_intraday = data[data['deltaDay'] == -1].set_index('tradeTime').sort_index()
    data_dayahead = data_dayahead[columns_gx]
    data_dayahead_clear = data_dayahead_clear[columns_gx]
    data_intraday = data_intraday[columns_gx]
    data_dayahead.columns = ['dayahead_' + c for c in columns_gx]
    data_dayahead_clear.columns = ['dayahead_clear_' + c for c in columns_gx]
    data_intraday.columns = ['intraday_' + c for c in columns_gx]
    data = pd.concat([data_dayahead, data_dayahead_clear, data_intraday], axis=1)
    return data


def get_shandong_gx_prediction(start_date, end_date=None):
    daas_url, accesskey, secretkey = read_config()
    start_time = start_date
    if end_date is None:
        end_time = str((pd.Timestamp(start_time) + pd.Timedelta(1, 'D')).date())
    else:
        end_time = str((pd.Timestamp(end_date) + pd.Timedelta(1, 'D')).date())
    url_gx = f'https://{daas_url}/trading-terminal-api/v1/center-base/forecast/' \
             f'supply-demand?provinceCode={province_code}' \
             f'&siteId=&startDay={start_time}&endDay={end_time}'
    url_gx = url_gx.replace(" ", "%20")
    t = time.time()
    r = poseidon.urlopen(accesskey, secretkey, url_gx, timeout=100)
    print('gx prediction time:', time.time() - t)
    data = pd.DataFrame(r['data'])
    data['publishDay'] = pd.to_datetime(data['publishDay'])
    data['tradeTime'] = data['tradeTime'].apply(lambda x: str(pd.Timestamp(x[:10]) + pd.Timedelta(1, 'D'))
    if x[-8:] == '24:00:00' else x)
    data['tradeTime'] = pd.to_datetime(data['tradeTime']) - pd.Timedelta(15, 'min')
    data['deltaDay'] = (data['tradeTime'] - data['publishDay']).apply(lambda x: x.days)
    gx_prediction = []
    for d in range(2, 10):
        data_d = data.loc[data['deltaDay'] == d]
        if len(data_d) > 0:
            data_d = data_d.set_index('tradeTime').sort_index()
            data_d = data_d[['loadRegulation', 'tieLineLoad', 'wind', 'solar']]
            data_d.columns = ['loadRegulation_d' + str(d), 'tieLineLoad_d' + str(d), 'wind_d' + str(d),
                              'solar_d' + str(d)]
            gx_prediction.append(data_d)
    gx_prediction = pd.concat(gx_prediction, axis=1)
    return gx_prediction


def get_shandong_price(start_date, end_date=None, node=node):
    daas_url, accesskey, secretkey = read_config()
    if end_date is None:
        end_date = str((pd.Timestamp(start_date) + pd.Timedelta(1, 'D')).date())
    else:
        end_date = str((pd.Timestamp(end_date) + pd.Timedelta(1, 'D')).date())
    url_price = f'https://{daas_url}/trading-terminal-api/v1/price-real?' \
                f'provinceCode={province_code}&siteId=&' \
                f'name={node}&type=node&startDay={start_date}&endDay={end_date}'
    url_price = url_price.replace(" ", "%20")
    t = time.time()
    r = poseidon.urlopen(accesskey, secretkey, url_price, timeout=100)
    print('price time:', time.time() - t)
    data = pd.DataFrame(r['data'])
    data['tradeTime'] = data['tradeTime'].apply(lambda x: str(pd.Timestamp(x[:10]) + pd.Timedelta(1, 'D'))
    if x[-8:] == '24:00:00' else x)
    data['tradeTime'] = pd.to_datetime(data['tradeTime']) - pd.Timedelta(15, 'min')
    data = data.set_index('tradeTime').sort_index()
    data = data[columns_price]
    return data


def get_shandong_price_prediction(start_date, end_date=None, node=node):
    daas_url, accesskey, secretkey = read_config()
    if end_date is None:
        end_date = str((pd.Timestamp(start_date) + pd.Timedelta(1, 'D')).date())
    else:
        end_date = str((pd.Timestamp(end_date) + pd.Timedelta(1, 'D')).date())
    url_price = f'https://{daas_url}/trading-terminal-api/v1/center-base/price-forecast?' \
                f'provinceCode={province_code}&siteId=&' \
                f'name={node}&type=node&startDay={start_date}&endDay={end_date}'
    url_price = url_price.replace(" ", "%20")
    t = time.time()
    r = poseidon.urlopen(accesskey, secretkey, url_price, timeout=100)
    print('price prediction time:', time.time() - t)
    data = pd.DataFrame(r['data'])
    data['tradeTime'] = data['tradeTime'].apply(lambda x: str(pd.Timestamp(x[:10]) + pd.Timedelta(1, 'D'))
    if x[-8:] == '24:00:00' else x)
    data['tradeTime'] = pd.to_datetime(data['tradeTime']) - pd.Timedelta(15, 'min')
    data['publishDay'] = pd.to_datetime(data['publishDay'])
    data['deltaDay'] = (data['tradeTime'] - data['publishDay']).apply(lambda x: x.days)
    price_prediction_d1 = data[data['deltaDay'] == 1].set_index('tradeTime').sort_index()[columns_price]
    price_prediction_d1.columns = [c + '_d1' for c in columns_price]
    price_prediction_dn = []
    for d in range(2, 10):
        data_d = data.loc[data['deltaDay'] == d]
        if len(data_d) > 0:
            data_d = data_d.set_index('tradeTime').sort_index()
            data_d = data_d[['daClearingPriceBeforeReduce']]
            data_d.columns = ['daClearingPriceBeforeReduce_d' + str(d)]
            price_prediction_dn.append(data_d)
    data = pd.concat([price_prediction_d1] + price_prediction_dn, axis=1)
    return data


def get_shandong_data(start_date, end_date=None, node=node):
    data_gx = get_shandong_gx(start_date, end_date)
    data_price = get_shandong_price(start_date, end_date, node)
    data_price_prediction = get_shandong_price_prediction(start_date, end_date, node)
    data_gx_prediction = get_shandong_gx_prediction(start_date, end_date)
    data = pd.concat([data_gx, data_price, data_price_prediction, data_gx_prediction], axis=1)
    data = data.reindex(columns=list(columns_map)).rename(columns=columns_map).dropna(axis=1, how='all')
    return data


def get_shandong_month_typical_gx_prediction(start_time='2021-12', end_time=None):
    daas_url, accesskey, secretkey = read_config()
    if end_time is None:
        end_time = pd.Timestamp(datetime.now(tz=pytz.timezone('Asia/Shanghai')))
    else:
        end_time = pd.Timestamp(end_time)
    end_time = end_time + pd.offsets.MonthBegin(1)
    end_time = end_time.strftime('%Y-%m')
    url_gx = f'https://{daas_url}/trading-terminal-api/v1/center-base/forecast/supply-demand-typical' \
             f'?provinceCode={province_code}&type=month&startTime={start_time}&endTime={end_time}'
    url_gx = url_gx.replace(" ", "%20")
    t = time.time()
    r = poseidon.urlopen(accesskey, secretkey, url_gx, timeout=100)
    print('gx prediction time:', time.time() - t)
    data = pd.DataFrame(r['data'])
    data['time'] = data['time'].apply(lambda x: pd.Timedelta(x + ':00') - pd.Timedelta(15, 'min')
    if x != '24:00' else pd.Timedelta('23:45:00'))
    data['time'] = pd.to_datetime(data['month']) + data['time']
    data = data[['time', 'loadRegulation', 'tieLineLoad', 'wind', 'solar']].dropna().set_index('time', drop=True)
    return data


def get_shandong_month_typical_price_prediction(start_time='2021-12', end_time=None):
    daas_url, accesskey, secretkey = read_config()
    if end_time is None:
        end_time = pd.Timestamp(datetime.now(tz=pytz.timezone('Asia/Shanghai')))
    else:
        end_time = pd.Timestamp(end_time)
    end_time = end_time + pd.offsets.MonthBegin(1)
    end_time = end_time.strftime('%Y-%m')
    url_price = f'https://{daas_url}/trading-terminal-api/v1/center-base/forecast/price-typical?' \
                f'provinceCode={province_code}&name=shandong&priceType=province&forecastType=month&' \
                f'startTime={start_time}&endTime={end_time}'
    url_price = url_price.replace(" ", "%20")
    t = time.time()
    r = poseidon.urlopen(accesskey, secretkey, url_price, timeout=100)
    print('price prediction time:', time.time() - t)
    data = pd.DataFrame(r['data'])
    data['time'] = data['time'].apply(lambda x: pd.Timedelta(x + ':00') - pd.Timedelta(15, 'min')
    if x != '24:00' else pd.Timedelta('23:45:00'))
    data['time'] = pd.to_datetime(data['month']) + data['time']
    data = data[['time', 'price']].dropna().set_index('time', drop=True)
    return data


def get_shandong_month_typical_prediction(start_time='2021-12', end_time=None):
    gx_prediction = get_shandong_month_typical_gx_prediction(start_time, end_time)
    price_prediction = get_shandong_month_typical_price_prediction(start_time, end_time)
    month_typical_prediction = pd.concat([gx_prediction, price_prediction], axis=1)
    return month_typical_prediction


def get_shandong_average_price_prediction(start_date, end_date):
    daas_url, accesskey, secretkey = read_config()
    end_date = str((pd.Timestamp(end_date) + pd.Timedelta(1, 'D')).date())
    url_price = f'https://{daas_url}/trading-terminal-api/v1/center-base/price-forecast-avg?' \
                f'provinceCode={province_code}&name=shandong&type=province&' \
                f'startDay={start_date}&endDay={end_date}'
    url_price = url_price.replace(" ", "%20")
    t = time.time()
    r = poseidon.urlopen(accesskey, secretkey, url_price, timeout=100)
    print('price prediction time:', time.time() - t)
    data = pd.DataFrame(r['data'])
    data = data[['tradeDay', 'publishDay', 'daClearingPriceBeforeReduce']]
    data.columns = ['trade_date', 'publish_date', 'price_prediction']
    data['trade_date'] = pd.to_datetime(data['trade_date'])
    data['publish_date'] = pd.to_datetime(data['publish_date'])
    data = data.set_index('trade_date').sort_index()
    return data


if __name__ == '__main__':
    t = time.time()

    data = get_shandong_data(start_date='2023-09-01', end_date='2024-03-01')
    # data_month_typical = get_shandong_month_typical_prediction(start_time='2021-12', end_time='2023-02')
    # data_average_price = get_shandong_average_price_prediction(start_date='2023-02-23', end_date='2023-03-08')
    print(time.time() - t)

    pass
