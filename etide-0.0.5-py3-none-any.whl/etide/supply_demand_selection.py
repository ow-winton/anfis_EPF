import pandas as pd
import itertools
import seaborn as sns
from matplotlib import pyplot as plt
from dateutil.relativedelta import relativedelta

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号


class SupplyDemandSelection(object):

    def __init__(self, input_df: pd.DataFrame(), time_col: str, target_col: str, col_list: list):
        """
        dataframe变量相关性分析
        :param input_df: 输入dataframe
        :param time_col: 时间列名称, 例如'timestamp'
        :param target_col: 目标列名称, 例如'实时电价'
        :param col_list: 测试组合列表, 例如['负荷', '联络线', '新能源']
        :return:
        """
        self.df = input_df.copy()
        self.time_col = time_col
        self.target_col = target_col
        self.col_list = col_list

        '缓存变量'
        self.comb_list = None
        self.comb_corr = None

    def get_col_combination(self, drop_opposite=True):
        """
        获取字符串列表排列组合
        :param drop_opposite: 舍弃相反组合, 例如a+b与-a-b为相反组合,则只保留其中一个
        :return: 组合列表
        :return:
        """
        str_type = [[f'+{s}', f'-{s}', '0'] for s in self.col_list]

        self.comb_list = []
        for comb in itertools.product(*str_type):
            '确定组合名称'
            comb_name = ''.join([c for c in comb if '0' not in c])
            comb_name_sign = comb_name.translate(str.maketrans({'+': '-', '-': '+'}))
            '组合过滤'
            if comb_name == '':  # 剔除空组合
                continue
            elif drop_opposite and comb_name_sign in self.comb_list:  # 剔除相反组合
                continue
            else:
                self.comb_list.append(comb_name)

        return self.comb_list

    def get_comb_value(self, col_comb: str):
        """
        根据组合列名称计算组合列数值
        :param col_comb: 组合列名称，一般为'a+b-c'
        :return:
        """
        self.df[col_comb] = 0
        for c in self.col_list:
            if c in col_comb:
                sign = col_comb.split(c)[0][-1]
                self.df[col_comb] += self.df[c] if sign == '+' else -self.df[c]

        return self.df[col_comb].values

    def get_monthly_correlation(self, x_col: str, y_col: str, method='pearson', get_mean=True):
        """
        获取输入列与目标列的月度相关性
        :param x_col: 输入列名称, 例如竞价空间
        :param y_col: 目标列名称, 例如实时电价
        :param method: 相关性方法, 支持pands的{‘pearson’, ‘kendall’, ‘spearman’} or callable
        :param get_mean: 是否获取平均值
        :return:
        """
        corr_df = pd.DataFrame(columns=['month', x_col])
        sta_date, end_date = self.df[self.time_col].dt.date.min(), self.df[self.time_col].dt.date.max()
        test_months = pd.date_range(sta_date, end_date, freq='MS')

        for m in test_months:
            month_sta, month_end = m, m + relativedelta(months=1)
            month_df = self.df.loc[(self.df[self.time_col] >= month_sta) & (self.df[self.time_col] < month_end)]
            month_corr = month_df[[x_col, y_col]].corr(method=method).round(4).iloc[0, 1]
            corr_df.loc[len(corr_df)] = [m.strftime('%Y-%m'), month_corr]

        if get_mean:
            corr_df.loc[len(corr_df)] = ['average', corr_df.mean()[0]]
            corr_df.loc[len(corr_df)] = ['average_abs', corr_df.iloc[:, 1:].abs().mean()[0]]

        return corr_df

    def get_comb_correlation(self, method='pearson', save_dir=None):
        """
        获取供需组合的相关性
        :param method: 相关性方法, 支持pands的{‘pearson’, ‘kendall’, ‘spearman’} or callable
        :param save_dir:
        :return:
        """
        if self.comb_list is None:
            self.get_col_combination()

        self.comb_corr = pd.DataFrame()
        for comb in self.comb_list:
            print(f'测试组合:{comb}')
            self.df[comb] = self.get_comb_value(comb)
            comb_df = self.get_monthly_correlation(x_col=comb, y_col=self.target_col, method=method, get_mean=True)
            self.comb_corr = comb_df if self.comb_corr.empty else pd.merge(self.comb_corr, comb_df, on=['month'])
        self.comb_corr = self.comb_corr.set_index('month').T.reset_index().rename(columns={'index': 'comb_name'})

        if save_dir is not None:
            self.comb_corr.to_excel(f'{save_dir}/comb_correlation.xlsx', index=False, encoding='utf-8-sig')

        return self.comb_corr

    def plot_topn_scatter(self, topn=5, save_dir=None, pause_time=5):
        """
        绘制topN组合列的相关性
        :param topn: 绘制组合中topn的相关性图
        :param save_dir: 图片保存目录
        :param pause_time: 窗口显示时间
        :return:
        """
        '数据检查'
        if self.comb_corr is None:
            self.get_comb_correlation()

        topN = 6
        topn_df = self.comb_corr.nlargest(topN, columns=['average_abs'])
        name_list = topn_df['comb_name'].tolist()

        plot_df = self.df.copy()
        plot_df['month'] = plot_df[self.time_col].dt.strftime('%Y-%m')

        fig, axs = plt.subplots(topn // 3, 3, constrained_layout=True)
        for i, name in enumerate(name_list):
            ax = axs[i // 3, i % 3]
            coff = self.comb_corr.loc[self.comb_corr['comb_name'] == name, 'average'].iloc[0]
            ax.set_title(f'{name}:{coff: 0.3f}')
            sns.scatterplot(data=plot_df, x=name, y=self.target_col, hue='month', legend='full', ax=ax, sizes=[1])

        '窗口定时关闭'
        if pause_time is not None:
            plt.pause(pause_time)
        else:
            plt.show()

        if save_dir is not None:
            fig.savefig(f'{save_dir}/comb_correlation.jpg', dpi=300, bbox_inches='tight')

    def plot_comb_scatter(self, comb, save_dir=None, pause_time=5):
        """
        绘制topN组合列的相关性
        :param comb: 绘制组合中topn的相关性图
        :param save_dir: 图片保存目录
        :param pause_time: 窗口显示时间
        :return:
        """
        '数据处理'
        self.get_comb_value(comb)
        temp_df = self.get_monthly_correlation(x_col=comb, y_col=self.target_col)
        coff = temp_df.set_index('month').T.reset_index()['average'].iloc[0]

        plot_df = self.df.copy()
        plot_df['month'] = plot_df[self.time_col].dt.strftime('%Y-%m')
        fig, ax = plt.subplots(1, constrained_layout=True)
        ax.set_title(f'{comb}:{coff: 0.3f}')
        sns.scatterplot(data=plot_df, x=comb, y=self.target_col, hue='month', legend='full', ax=ax, sizes=[1])

        '窗口定时关闭'
        if pause_time is not None:
            plt.pause(pause_time)
        else:
            plt.show()

        if save_dir is not None:
            fig.savefig(f'{save_dir}/correlation.jpg', dpi=300, bbox_inches='tight')


if __name__ == '__main__':

    '数据读取'
    df = pd.read_excel('../data/山东供需电价数据.xlsx', parse_dates=['index']).rename(columns={'index': 'timestamp'})

    '参数设置'
    sta_date = pd.to_datetime('2023-01-01')
    end_date = pd.to_datetime('2023-03-01')
    time_col = 'timestamp'
    target_col = '日前_电价(元/MWh)'
    gx_cols = ['出清前_直调负荷(MW)', '出清前_联络线受电负荷(MW)', '出清前_风电总加(MW)', '出清前_光伏总加(MW)', '出清前_抽蓄(MW)']

    use_df = df.loc[(df[time_col] >= sta_date) & (df[time_col] < end_date)].copy()
    # use_df = use_df.set_index(time_col).resample('1h').mean().reset_index()

    '获取供需分项排列组合'
    SDS = SupplyDemandSelection(input_df=use_df, time_col=time_col, target_col=target_col, col_list=gx_cols)
    comb_list = SDS.get_col_combination(drop_opposite=True)  # 获取组合列表
    comb_data = SDS.get_comb_value(comb_list[0])  # 获取组合列数值
    comb_corr = SDS.get_comb_correlation(method='pearson')  # 计算所有组合列月均相关性
    col_corr = SDS.get_monthly_correlation(comb_list[0], target_col)  # 计算指定列月均相关性并绘图

    SDS.plot_topn_scatter(topn=6)  # 绘制topN相关组合的scatter图
    SDS.plot_comb_scatter('+出清前_直调负荷(MW)-出清前_联络线受电负荷(MW)-出清前_风电总加(MW)-出清前_光伏总加(MW)')

    pass
