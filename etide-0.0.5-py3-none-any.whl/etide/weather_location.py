import json
import requests
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号


def is_poi_within_poly(point, poly):
    """
    射线法判断点是否在多边形内,被检测点向某一方向做射线,交点个数为奇数则在多边形内
    determine whether a point is inside a polygon using the ray method
    :param point: [x, y], 1x1 list, coordinate of point
    :param poly: [[[x1,y1],[x2,y2],...,[xn,yn]]], 1x2xN list, boundary coordinates of polygon
    :return: True or False
    """

    # 点；多边形三维数组；容限
    # poly=[[[x1,y1],[x2,y2],……,[xn,yn],[x1,y1]],[[w1,t1],……[wk,tk]]] 三维数组

    def is_poi_within_box(poi, sbox):
        """
        判断点是否在矩形内
        determine whether the point is within the bouding rectangle
        :param poi: [x, y], 1x1 list, coordinate of point
        :param sbox: [[x1,y1],[x2,y2]], 2x2 list, upper left and lower right coordinates of box
        :return: True or False
        """
        # 不考虑在边界上，需要考虑就加等号
        if sbox[0][0] < poi[0] < sbox[1][0] and sbox[0][1] < poi[1] < sbox[1][1]:
            return True
        return False

    def is_ray_intersects_segment(poi, s_poi, e_poi):  # [x,y] [lng,lat]
        """
        判断射线是否与边有交点
        determine whether the ray intersects with the edge
        :param poi: [x, y], 1x1 list, coordinate of point
        :param s_poi: [x, y], 1x1 list, start coordinate of ray
        :param e_poi: [x, y], 1x1 list, end coordinate of ray
        :return: True or False
        """
        if s_poi[1] == e_poi[1]:  # 排除与射线平行、重合，线段首尾端点重合的情况
            return False
        if s_poi[1] > poi[1] and e_poi[1] > poi[1]:
            return False
        if s_poi[1] < poi[1] and e_poi[1] < poi[1]:
            return False
        if s_poi[1] == poi[1] and e_poi[1] > poi[1]:
            return False
        if e_poi[1] == poi[1] and s_poi[1] > poi[1]:
            return False
        if s_poi[0] < poi[0] and e_poi[1] < poi[1]:
            return False
        xseg = e_poi[0] - (e_poi[0] - s_poi[0]) * (e_poi[1] - poi[1]) / (e_poi[1] - s_poi[1])  # 求交
        if xseg < poi[0]:
            return False
        return True

    # 先判断点是否在外包矩形内,是否在经纬度内
    if not is_poi_within_box(point, [[0, 0], [180, 90]]):
        return False

    sinsc = 0  # 交点个数
    for epoly in poly:  # 逐个二维数组进行判断
        for i in range(len(epoly) - 1):  # [0, len-1]
            s_point = epoly[i]
            e_point = epoly[i + 1]
            if is_ray_intersects_segment(point, s_point, e_point):
                sinsc += 1

    return sinsc % 2 != 0  # 这样更简洁些


class CnProvincialLonLat:
    """
    获取中国的省市内的城市或者网格经纬度坐标
    References:
    https://lbs.amap.com/api/webservice/guide/api/distric
    https://github.com/QLWeilcf/LcfGeoProject/blob/master/poiWithinPolygon.py
    https://github.com/cshgiser/GIS-Spatial-relationship-between-point-and-ploygon/blob/main/pointInPloygon.py
    """

    def __init__(self, province):
        """

        :param province: str, '甘肃', chinese name of province
        :return:
        """
        self.prov = province
        self.margin_df = self.get_margin()

        '用于绘图的缓存变量'
        self.city_dict = {}
        self.all_points = []
        self.in_points = []
        self.out_points = []

    def get_margin(self):
        """
        获取省市边界经纬度坐标
        get the latitude and longitude coordinates of the provincial border
        :return: pd.DataFrame(), 省市边界经纬度的dataframe
        """
        '参考https://lbs.amap.com/api/webservice/guide/api/district申请高德API key'
        key = 'f30107cf5e9c2795c7708fdfabf2c734'
        url = f'https://restapi.amap.com/v3/config/district?key={key}&keywords={self.prov}&subdistrict=0&extensions=all'
        r = requests.get(url).json()

        ployline_str = r['districts'][0]['polyline']
        area_num = [len(x) for x in ployline_str.split('|')]
        print(f'{self.prov}有{len(area_num)}个独立区域！')

        ployline = []
        # '保留所有独立区域'
        # for area in ployline_str.split('|'):
        #     for corr_str in area.split(';'):
        #         lon, lat = corr_str.split(',')
        #         ployline.append([float(lon), float(lat)])

        '保留主要区域,例如山东有很多岛屿都删除'
        all_area = ployline_str.split('|')
        lens = [len(a) for a in all_area]
        main_area = all_area[lens.index(max(lens))]

        for corr_str in main_area.split(';'):
            lon, lat = corr_str.split(',')
            ployline.append([float(lon), float(lat)])

        ploy_df = pd.DataFrame(ployline, columns=['lon', 'lat'])

        return ploy_df

    def get_city(self):
        """
        获取城市级别经纬度坐标
        get the latitude and longitude coordinates of province city
        :return: dict,包含城市经纬度信息的字典
        """
        '参考https://lbs.amap.com/api/webservice/guide/api/district申请高德API key'
        key = 'f30107cf5e9c2795c7708fdfabf2c734'
        url = f'https://restapi.amap.com/v3/config/district?key={key}&keywords={self.prov}&' \
              f'subdistrict=2&extensions=base'

        r = requests.get(url).json()
        city_info = r['districts'][0]['districts']

        city_dict = {}
        for c in city_info:
            lon, lat = c['center'].split(',')
            name = c['name']
            name = name[:-5] if '自治州' in name else name[:-1]

            city_dict[name] = {'lon': float(lon), 'lat': float(lat)}

        self.city_dict = city_dict
        print(f'{self.prov}有{len(city_info)}个城市！')

        return city_dict

    def get_grid(self, lon_step=1.0, lat_step=1.0):
        """
        获取网格级别经纬度坐标
        get grid latitude and longitude coordinates of provinces
        :param lon_step: float, 0.5, custom longitude interval
        :param lat_step: float, 0.5, custom latitude interval
        :return: dict,包含网格经纬度信息的字典
        """
        ploygon = [self.margin_df.values.tolist()]
        lon_start, lon_end = self.margin_df['lon'].min(), self.margin_df['lon'].max()
        lat_start, lat_end = self.margin_df['lat'].min(), self.margin_df['lat'].max()
        eplison = 0.001

        count = 0
        grid_dict = {}
        '提取边界内网格点'
        for lat in np.arange(lat_start, lat_end + lat_step - eplison, lat_step):
            for lon in np.arange(lon_start, lon_end + lon_step - eplison, lon_step):
                lon, lat = np.round(lon, 3), np.round(lat, 3)
                point = (lon, lat)
                self.all_points.append(list(point))
                if is_poi_within_poly(point, ploygon) == 1:
                    grid_dict[f'point_{count}'] = {'lon': lon, 'lat': lat}
                    count += 1
                    self.in_points.append(list(point))
                else:
                    self.out_points.append(list(point))

        print(f'网格有{len(self.in_points)}个格点！')

        return grid_dict

    def plot_city(self, drop_list=None, save_dir=None, pause_time=None):
        """
        绘制城市经纬度坐标图
        :param drop_list: list, points where weather data cannot be obtained
        :param save_dir: str, if not None then save in this directory
        :param pause_time: int, pause time of image window
        :return: None
        """
        if len(self.city_dict) == 0:
            self.get_city()

        '绘图'
        fig, ax = plt.subplots()

        '绘制省边界线'
        plt.fill(self.margin_df['lon'].values, self.margin_df['lat'].values, fill=False, edgecolor='k', zorder=0)

        '绘制所有城市'
        city_df = pd.DataFrame(self.city_dict).T.astype('float')
        cit_names = city_df.index.tolist()
        plot_data = city_df.values
        plt.scatter(plot_data[:, 0], plot_data[:, 1], color='b', s=4 ** 2, zorder=2)
        for i, point in enumerate(plot_data):
            scale = 0.05
            point_text = (point[0] + scale, point[1] + scale)
            plt.annotate(f'{cit_names[i]}', xy=point, xytext=point_text, size=8)
        '绘制界内丢弃点'
        if drop_list is not None:
            plot_data = city_df[city_df.index.isin(drop_list)].values
            plt.scatter(plot_data[:, 0], plot_data[:, 1], color='gray', s=4 ** 2, zorder=2)
        '图片说明'
        plt.title(f'{self.prov}有{len(self.city_dict)}个城市')
        plt.xlabel('经度')
        plt.ylabel('纬度')

        '窗口定时关闭'
        if pause_time is not None:
            plt.pause(pause_time)
            # plt.close(fig)
        else:
            plt.show()

        if save_dir is not None:
            fig.savefig(f'{save_dir}/{self.prov}_city.jpg', dpi=300, bbox_inches='tight')

    def plot_grid(self, lon_step=1.0, lat_step=1.0, drop_list=None, save_dir=None, pause_time=None):
        """
        绘制网格级别坐标图
        :param lon_step: float, 1.0, custom longitude interval
        :param lat_step: float, 1.0, custom latitude interval
        :param save_dir: str, if not None then save in this directory
        :param drop_list: list, points where weather data cannot be obtained or need to be droped
        :param pause_time: int, pause time of image window
        :return: None
        """
        if len(self.all_points) == 0:
            self.get_grid(lon_step, lat_step)

        '绘图'
        fig, ax = plt.subplots()

        '绘制省边界线'
        plt.fill(self.margin_df['lon'].values, self.margin_df['lat'].values, fill=False, edgecolor='k', zorder=0)

        '绘制网格线'
        eplison = 0.001
        lon_start, lon_end = self.margin_df['lon'].min(), self.margin_df['lon'].max()
        lat_start, lat_end = self.margin_df['lat'].min(), self.margin_df['lat'].max()
        lon_end = np.arange(lon_start, lon_end + lon_step - eplison, lon_step)[-1]
        lat_end = np.arange(lat_start, lat_end + lat_step - eplison, lat_step)[-1]
        for lon in np.arange(lon_start, lon_end + lon_step - eplison, lon_step):
            plt.plot((lon, lon), (lat_start, lat_end), linestyle=':', color='gray', zorder=1)
        for lat in np.arange(lat_start, lat_end + lat_step - eplison, lat_step):
            plt.plot((lon_start, lon_end), (lat, lat), linestyle=':', color='gray', zorder=1)
        '绘制界内点'
        plot_data = np.array(self.in_points)
        plt.scatter(plot_data[:, 0], plot_data[:, 1], color='b', s=4 ** 2, zorder=2)
        for i, point in enumerate(self.in_points):
            scale = 0.05
            point_text = (point[0] + scale, point[1] + scale)
            plt.annotate(f'{i}', xy=point, xytext=point_text)
        '绘制界内丢弃点'
        if drop_list is not None:
            drop_points = [self.in_points[int(i.split('_')[1])] for i in drop_list]
            plot_data = np.array(drop_points)
            plt.scatter(plot_data[:, 0], plot_data[:, 1], color='gray', s=4 ** 2, zorder=2)
        '绘制界外点'
        plot_data = np.array(self.out_points)
        plt.scatter(plot_data[:, 0], plot_data[:, 1], color='r', s=4 ** 2, zorder=2)

        '图片说明'
        point_num = len(self.in_points) if drop_list is None else len(self.in_points) - len(drop_list)
        plt.title(f'{self.prov}网格经纬度,纬度间隔{lon_step},经度间隔{lat_step},边界内(蓝色)有{point_num}个点')
        plt.xlabel('经度')
        plt.ylabel('纬度')
        '窗口定时关闭'
        if pause_time is not None:
            plt.pause(pause_time)
        else:
            plt.show()

        if save_dir is not None:
            fig.savefig(f'{save_dir}/{self.prov}_grid.jpg', dpi=300, bbox_inches='tight')

    def plot_point(self, plot_df, lon_step=1.0, lat_step=1.0, show_name=False, save_dir=None, pause_time=None, ax=None, c=None):
        """
        绘制指定点坐标图
        :param plot_df: pd.DataFrame(), include three columns(index_name, lon, lat)
        :param lon_step: float, 1.0, custom longitude interval
        :param lat_step: float, 1.0, custom latitude interval
        :param show_name: bool, wheather to show name of point
        :param save_dir: str, if not None then save in this directory
        :param pause_time: int, pause time of image window
        :param ax: previously created matplotlib ax object, if None create a new one
        :param c: point color, if None default to 'b'
        :return: matplotlib ax object
        """
        if len(plot_df) == 0:
            print('无可绘制点')

        if ax is None:
            '绘图'
            fig, ax = plt.subplots()

            '绘制省边界线'
            plt.fill(self.margin_df['lon'].values, self.margin_df['lat'].values, fill=False, edgecolor='k', zorder=0)

            '绘制网格线'
            eplison = 0.001
            lon_start, lon_end = self.margin_df['lon'].min(), self.margin_df['lon'].max()
            lat_start, lat_end = self.margin_df['lat'].min(), self.margin_df['lat'].max()
            lon_end = np.arange(lon_start, lon_end + lon_step - eplison, lon_step)[-1]
            lat_end = np.arange(lat_start, lat_end + lat_step - eplison, lat_step)[-1]
            for lon in np.arange(lon_start, lon_end + lon_step - eplison, lon_step):
                plt.plot((lon, lon), (lat_start, lat_end), linestyle=':', color='gray', zorder=1)
            for lat in np.arange(lat_start, lat_end + lat_step - eplison, lat_step):
                plt.plot((lon_start, lon_end), (lat, lat), linestyle=':', color='gray', zorder=1)
        '绘制界内点'
        plot_data = np.array(plot_df[['lon', 'lat']])
        if c is None:
            c = 'b'
        plt.scatter(plot_data[:, 0], plot_data[:, 1], color=c, s=4 ** 2, zorder=2)
        if show_name:
            point_names = plot_df.index.tolist()
            for i, point in enumerate(plot_data):
                scale = 0.05
                point_text = (point[0] + scale, point[1] + scale)
                plt.annotate(f'{point_names[i]}', xy=point, xytext=point_text)

        '图片说明'
        plt.title(f'{self.prov}网格经纬度,纬度间隔{lon_step},经度间隔{lat_step},绘制{len(plot_data)}个点')
        plt.xlabel('经度')
        plt.ylabel('纬度')
        '窗口定时关闭'
        if pause_time is not None:
            plt.pause(pause_time)
        else:
            plt.show()

        if save_dir is not None:
            plt.savefig(f'{save_dir}/{self.prov}_point.jpg', dpi=300, bbox_inches='tight')
        return ax


if __name__ == '__main__':
    '经验丢弃点'
    prov_drop_dict = {
        '甘肃': [0, 1, 2, 3, 4, 6, 12, 16, 18, 19, 24, 31, 36, 38, 39, 41],  # lon_step=1, lat_step=1
        '内蒙古': [],  # lon_step=1, lat_step=1
        '山东': [],  # lon_step=1, lat_step=1
        '山西': [],  # lon_step=1, lat_step=1
    }

    '城市级别经纬度获取'
    # name = '内蒙古'
    # PLL = CnProvincialLonLat(name)
    # city_ll = PLL.get_city()
    # print(city_ll)
    # # json.dump(city_ll, open(f'{name}_city.json', 'w'))
    #
    # drop_list = ['通辽', '赤峰', '呼伦贝尔', '兴安']
    # PLL.plot_city(drop_list=drop_list, save_dir=None)
    #
    # city_ll_fiter = {key: val for key, val in city_ll.items() if key not in drop_list}
    # # json.dump(city_ll_fiter, open(f'{name}_city.json', 'w'))

    '网格级别经纬度获取'
    # name = '内蒙古'
    # lon_step, lat_step = 1.2, 1.2
    #
    # PLL = CnProvincialLonLat(name)
    # grid_ll = PLL.get_grid(lon_step, lat_step)
    # print(grid_ll)
    # # json.dump(grid_ll, open(f'{name}_grid.json', 'w'))
    #
    # drop_list_1 = [int(key.split('_')[1]) for key, val in grid_ll.items() if val['lon'] > 115]
    # drop_list_2 = [int(key.split('_')[1]) for key, val in grid_ll.items() if val['lon'] < 105]
    # drop_list = [f'point_{i}' for i in drop_list_1 + drop_list_2]
    # PLL.plot_grid(lon_step, lat_step, drop_list=drop_list, save_dir=None)
    #
    # # 丢弃无法拉取的点,重新保存经纬度坐标
    # grid_ll_fiter = {key: val for key, val in grid_ll.items() if key not in drop_list}
    # # json.dump(grid_ll_fiter, open(f'{name}_grid.json', 'w'))

    '绘制省内场站坐标'
    # name = '内蒙古'
    # lon_step, lat_step = 1.2, 1.2
    #
    # PLL = CnProvincialLonLat(name)
    # grid_ll = PLL.get_grid(lon_step, lat_step)
    #
    # test_json = {'乌兰察布': {'lat': 40.99, 'lon': 113.12}, 'test': {'lat': 44, 'lon': 114}}
    # plot_df = pd.DataFrame(test_json).T
    # PLL.plot_point(plot_df, lon_step=lon_step, lat_step=lat_step, show_name=True)

    '山东测试'
    name = '海南'
    lon_step, lat_step = 0.1, 0.1

    PLL = CnProvincialLonLat(name)
    grid_ll = PLL.get_grid(lon_step, lat_step)
    PLL.plot_grid(lon_step, lat_step, drop_list=None, save_dir=None)
    json.dump(grid_ll, open(f'{name}_grid.json', 'w'))
    # grid_ll_fiter = {key: val for key, val in grid_ll.items() if key not in prov_drop_dict[name]}

    # PLL.plot_city(drop_list=None, save_dir=None)
    # PLL.plot_grid(lon_step, lat_step, drop_list=None, save_dir=None)

    pass
