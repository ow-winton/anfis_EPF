"""
包含模型优化框架，例如超参数寻优，特征选择等
"""
import copy
import numpy as np
import logging
import traceback

logger = logging.getLogger(__name__)


class FeatureSelectionRecursive:
    """
    通过迭代式添加特征来筛选最优特征组合，使用方式如下：
    feature_selecton_model = FeatureSelectionRecursive()
    feature_selecton_model.run()
    feature_list_best, accuracy_best = feature_selecton_model.get_result()
    """
    def __init__(self, data, feature_list, target, backtest_obj, evaluation_func,
            reserve_features=None, max_feature_num=None, feature_sort_func=None,
            feature_permutation=False, accuracy_compare_func=None, error_handler='ignore'):
        """
        初始化特征选择模型参数
        :param data: 输入数据，数据类型为dataframe，应包含所有特征列和目标列
        :param feature_list: 候选特征列表，数据类型为str list
        :param target: 目标列，数据类型为str
        :param backtest_obj: 模型回测BackTestBase对象
        :param evaluation_func: 模型精度计算函数，例如日均准确率，
                                当accuracy_compare_func为None时，evaluation_func函数返回结果为单值类型，值越大表示精度越高
                                接口形式为evaluation_func(y_true, y_pred) -> accuracy
        :param reserve_features: 指定特征优化时默认保留的特征，数据类型为None或者str list
        :param max_feature_num: 指定优化后最大特征个数，为None则表示不限制特征个数
        :param feature_sort_func: 特征重要性排序函数，在特征迭代优化前对特征进行排序，返回结果为str list类型，
                                  接口形式为feature_sort_func(data, feature_list, target) -> sorted_feature_list
        :param feature_permutation: 指定在特征迭代优化前是否对特征列表进行顺序随机打乱
        :param accuracy_compare_func: 指定模型精度比较方法函数，为None则采用默认的大小比较方法，
                                      不为None时，函数返回True(新模型精度优于当前最好精度)或者False(新模型精度不如当前最好精度)
                                      接口形式为accuracy_compare_func(accuracy: evaluation_func返回结果,
                                                            FeatureSelectionRecursive对象) -> accuracy_compare_result: bool
        :param error_handler: 指定在模型回测出错时的处理方式，"ignore":忽略错误并跳过当前模型回测过程，"raise":抛出错误并终止运行
        """
        self.data = data
        self.feature_list = feature_list
        self.target = target
        self.backtest_obj = backtest_obj
        self.evaluation_func = evaluation_func
        self.reserve_features = reserve_features
        self.max_feature_num = max_feature_num
        self.feature_sort_func = feature_sort_func
        self.feature_permutation = feature_permutation
        self.accuracy_compare_func = accuracy_compare_func
        self.error_handler = error_handler

    def run(self):
        """
        运行特征优化过程，得到最优特征组合以及最优回测精度指标
        :return:
        """
        logger.info('feature optimization starts running')
        if self.feature_permutation:
            feature_list = list(np.random.permutation(self.feature_list))
        else:
            if self.feature_sort_func is not None:
                feature_list = self.feature_sort_func(self.data, self.feature_list, self.target)
            else:
                feature_list = self.feature_list
        logger.info(f'feature list to be optimized:{feature_list}')
        backtest_obj = self.backtest_obj
        evaluation_func = self.evaluation_func
        model_name = backtest_obj.get_model_name()[0]
        self.feature_list_best = []
        self.accuracy_best = None
        if self.reserve_features is not None:
            feature_list_candid = copy.deepcopy(self.reserve_features)
            backtest_obj.set_model_params({model_name: {'feature_list': feature_list_candid}})
            logger.info(f'testing feature list:{feature_list_candid}')
            prediction = backtest_obj.run(self.data)
            prediction = prediction.squeeze()
            accuracy = evaluation_func(self.data.loc[prediction.index, self.target], prediction)
            logger.info(f'accuracy result:{accuracy}')
            self.accuracy_best = accuracy
            self.feature_list_best = copy.deepcopy(feature_list_candid)
        else:
            feature_list_candid = []
        for feature in feature_list:
            if feature not in feature_list_candid:
                feature_list_candid.append(feature)
                backtest_obj.set_model_params({model_name: {'feature_list': feature_list_candid}})
                logger.info(f'testing feature list:{feature_list_candid}')
                try:
                    prediction = backtest_obj.run(self.data)
                except:
                    logger.error(traceback.format_exc())
                    logger.error('back test fail')
                    if self.error_handler == 'ignore':
                        feature_list_candid = feature_list_candid[:-1]
                        continue
                    else:
                        raise Exception
                prediction = prediction.squeeze()
                accuracy = evaluation_func(self.data.loc[prediction.index, self.target], prediction)
                logger.info(f'accuracy result:{accuracy}')
                if self.accuracy_best is None:
                    accuracy_compare_result = True
                elif self.accuracy_compare_func is None:
                    accuracy_compare_result = accuracy > self.accuracy_best
                else:
                    accuracy_compare_result = self.accuracy_compare_func(accuracy, self)
                if accuracy_compare_result:
                    self.accuracy_best = accuracy
                    self.feature_list_best = copy.deepcopy(feature_list_candid)
                    logger.info(f'best feature list is updated:{self.feature_list_best}')
                    logger.info(f'best accuracy is updated:{self.accuracy_best}')
                    if self.max_feature_num is not None and len(self.feature_list_best) >= self.max_feature_num:
                        break
                else:
                    feature_list_candid = feature_list_candid[:-1]
                    logger.info(f'current best feature list :{self.feature_list_best}')
                    logger.info(f'current best accuracy :{self.accuracy_best}')
        logger.info(f'best feature list:{self.feature_list_best}')
        logger.info(f'best accuracy:{self.accuracy_best}')
        logger.info('feature optimization finished')

    def get_result(self):
        """
        返回最优特征组合以及最优回测精度指标
        :return:
        """
        return self.feature_list_best, self.accuracy_best


class GridSearchOptimization:
    """
    通过网格搜索寻优最优模型超参数，使用方式如下：
    grid_search_model = GridSearchOptimization()
    grid_search_model.run()
    model_param_best, accuracy_best = grid_search_model.get_result()
    """
    def __init__(self, data, target, param_grid, backtest_obj, evaluation_func,
                 accuracy_compare_func=None, error_handler='ignore'):
        """
        初始化网格搜索模型参数
        :param data: 输入数据，数据类型为dataframe，应包含所有特征列和目标列
        :param target: 目标列，数据类型为str
        :param param_grid: 模型超参数网格，数据类型为list of dict
        :param backtest_obj: 模型回测BackTestBase对象
        :param evaluation_func: 模型精度计算函数，例如日均准确率，
                                当accuracy_compare_func为None时，evaluation_func函数返回结果为单值类型，值越大表示精度越高
                                接口形式为evaluation_func(y_true, y_pred) -> accuracy
        :param accuracy_compare_func: 指定模型精度比较方法函数，为None则采用默认的大小比较方法，
                                      不为None时，函数返回True(新模型精度优于当前最好精度)或者False(新模型精度不如当前最好精度)
                                      接口形式为accuracy_compare_func(accuracy: evaluation_func返回结果,
                                                            GridSearchOptimization) -> accuracy_compare_result: bool
        :param error_handler: 指定在模型回测出错时的处理方式，"ignore":忽略错误并跳过当前模型回测过程，"raise":抛出错误并终止运行
        """
        self.data = data
        self.target = target
        self.param_grid = param_grid
        self.backtest_obj = backtest_obj
        self.evaluation_func = evaluation_func
        self.accuracy_compare_func = accuracy_compare_func
        self.error_handler = error_handler

    def run(self):
        """
        运行网格搜索模型超参数优化过程，得到最优模型超参数以及最优回测精度指标
        :return:
        """
        logger.info('grid search optimization starts running')
        param_grid = self.param_grid
        backtest_obj = self.backtest_obj
        evaluation_func = self.evaluation_func
        model_name = backtest_obj.get_model_name()[0]
        self.accuracy_best = None
        self.model_param_best = None
        self.accuracy_all = []
        grid_length = len(param_grid)
        for i, model_param in enumerate(param_grid):
            backtest_obj.set_model_params({model_name: model_param})
            logger.info(f'testing round:{i}/{grid_length}')
            logger.info(f'testing model param:{model_param}')
            try:
                prediction = backtest_obj.run(self.data)
            except:
                logger.error(traceback.format_exc())
                logger.error('back test fail')
                if self.error_handler == 'ignore':
                    continue
                else:
                    raise Exception
            prediction = prediction.squeeze()
            accuracy = evaluation_func(self.data.loc[prediction.index, self.target], prediction)
            logger.info(f'accuracy result:{accuracy}')
            self.accuracy_all.append(accuracy)
            if self.accuracy_best is None:
                accuracy_compare_result = True
            elif self.accuracy_compare_func is None:
                accuracy_compare_result = accuracy > self.accuracy_best
            else:
                accuracy_compare_result = self.accuracy_compare_func(accuracy, self)
            if accuracy_compare_result:
                self.accuracy_best = accuracy
                self.model_param_best = model_param
                logger.info(f'best model param is updated:{self.model_param_best}')
                logger.info(f'best accuracy is updated:{self.accuracy_best}')
            else:
                logger.info(f'current model param:{self.model_param_best}')
                logger.info(f'current best accuracy :{self.accuracy_best}')
        logger.info(f'best model param:{self.model_param_best}')
        logger.info(f'best accuracy:{self.accuracy_best}')
        logger.info('grid search optimization finished')

    def get_result(self):
        """
        返回最优模型超参数以及最优回测精度指标
        :return:
        """
        return self.model_param_best, self.accuracy_best, self.accuracy_all

