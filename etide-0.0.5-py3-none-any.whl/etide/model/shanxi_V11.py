#!/usr/bin/env python
# encoding: utf-8
"""
@author: zhenning.yang
@datetime: 2023/3/2 10:47
@desc: 山西V11模型
"""
import numpy as np
import pandas as pd
from etide.model_pipeline import ModelBase
from scipy.interpolate import UnivariateSpline
from etide.utils import get_date
from etide.data_similarity_match import sample_select_v2


class ShanxiV11(ModelBase):
    """
    基于竞价空间-电价样本排序的spline插值拟合模型
    """
    def __init__(self,
                 feature_list,
                 target,
                 name='ShanxiV11',
                 pred_feature_dict=None,
                 delay_days=2,
                 max_back_days=40,
                 pred_min=0,
                 pred_max=1500,
                 select_sample_func=True
                 ):
        super().__init__(
                 name,
                 feature_list,
                 target,
                 delay_days,
                 max_back_days,
                 pred_min,
                 pred_max,
                 pred_feature_dict
                 )
        self.s = 0
        # sum((w[i] * (y[i]-spl(x[i])))**2, axis=0) <= s
        self.sort_spline_linear = None
        self.is_normalize = False
        self.X_train = None
        self.y_train = None
        self.select_sample_func=select_sample_func

    def get_train_data(self, data, pred_date):
        # 选取训练样本集合
        if self.max_back_days is not None:
            sta_date = get_date(pred_date, shift_days=-self.max_back_days)
            data = data.loc[sta_date:]
        end_date = get_date(pred_date, shift_days=-self.delay_days)
        df_hist = data.loc[:end_date].dropna(subset=self.feature_list + [self.target])

        # implement your customized training data selection function here
        if self.select_sample_func:
            df_pred = data.loc[pred_date]
            if self.pred_feature_dict is not None:
                pred_space = self.pred_feature_dict[self.feature_list[0]]
            else:
                pred_space = self.feature_list[0]
            times_train = sample_select_v2(df_hist,
                                           df_pred,
                                           self.target,
                                           self.feature_list[0],
                                           pred_space,
                                           self.pred_max)
            df_train = df_hist.loc[times_train]
        else:
            df_train = df_hist

        train_feature = df_train[self.feature_list]
        train_target = df_train[self.target]
        return train_feature, train_target

    def build(self):
        self.sort_spline_linear = None

    def fit(self, X_train, y_train):
        self.build()
        X_train = X_train.values
        y_train = y_train.values
        self.X_train = X_train
        self.y_train = y_train
        y_train = self.y_train.copy()

        self.build()
        if len(X_train.shape) > 1:
            X_train = X_train.reshape((-1,))

        # 对训练样本X、y分别进行重排序shuffle
        X_train.sort()
        y_train.sort()
        try:
            self.sort_spline_linear = UnivariateSpline(X_train, y_train, k=1, s=self.s)
        except:
            X_train, index_no_repeat = np.unique(X_train, return_index=True)
            y_train = y_train[index_no_repeat]
            self.sort_spline_linear = UnivariateSpline(X_train, y_train, k=1, s=self.s)

    def predict(self, X_test):
        test_index = X_test.index
        X_test = X_test.values
        if len(X_test.shape) > 1:
            X_test = X_test.reshape((-1,))
        y_pred = self.sort_spline_linear(X_test)
        # 对预测做后处理，防止拟合斜率过大造成的影响
        if X_test.max() > self.X_train.max():
            if self.sort_spline_linear(X_test.max() + 1000) - self.y_train.max() > 500:
                y_pred[X_test > self.X_train.max()] = self.y_train.max()
        y_pred = np.clip(y_pred, self.pred_min, self.pred_max)
        y_pred = pd.Series(y_pred, index=test_index)
        return y_pred
