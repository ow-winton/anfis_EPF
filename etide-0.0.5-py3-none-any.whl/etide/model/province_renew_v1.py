#!/usr/bin/env python
# encoding: utf-8
"""
@author: zhenning.yang
@datetime: 2023/4/4 9:53
@desc: 全省新能源预测V1模型，简单LR线性模型，不同省份的特征工程需要使用特征选择重要性结果进行过滤筛选出最优特征子集
"""
import numpy as np
import pandas as pd
from etide.model_pipeline import ModelBase
from sklearn.linear_model import LinearRegression


class RenewV1(ModelBase):
    """
    新能源预测线性模型
    """

    def __init__(self,
                 feature_list,
                 target,
                 name='renew_v1',
                 pred_feature_dict=None,
                 delay_days=None,
                 max_back_days=50,
                 pred_min=0,
                 pred_max=25000,
                 select_sample_func=False
                 ):
        super().__init__(
            name,
            feature_list,
            target,
            delay_days,
            max_back_days,
            pred_min,
            pred_max,
            pred_feature_dict
        )
        self.select_sample_func = select_sample_func
        self.model = None

    def build(self):
        self.model = LinearRegression(normalize=True)

    def fit(self, X_train, y_train):
        self.build()
        X_train = X_train.values
        y_train = y_train.values
        self.model.fit(X_train, y_train)

    def predict(self, X_test):
        test_index = X_test.index
        X_test = X_test.values
        y_pred = self.model.predict(X_test)
        y_pred = np.clip(y_pred, self.pred_min, self.pred_max)
        y_pred = pd.Series(y_pred, index=test_index)
        return y_pred
