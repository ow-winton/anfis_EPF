import numpy as np
import pandas as pd
from xgboost import XGBRegressor
from sklearn.model_selection import cross_validate
from etide.model_pipeline import ModelBase


class XGBCV(ModelBase):
    """
    XGB with cross validation
    """
    def __init__(self,
                 feature_list,
                 target,
                 name='xgb_cv',
                 pred_feature_dict=None,
                 delay_days=1,
                 max_back_days=30,
                 pred_min=-80,
                 pred_max=1300,
                 cv=5,
                 points_per_day=96,
                 train_with_pred_feature=False
                 ):
        super().__init__(
                 name,
                 feature_list,
                 target,
                 delay_days,
                 max_back_days,
                 pred_min,
                 pred_max,
                 pred_feature_dict
                 )
        self.cv = cv
        self.points_per_day = points_per_day
        self.train_with_pred_feature = train_with_pred_feature

    def get_train_data(self, data, pred_date):
        train_feature, train_target = super().get_train_data(data, pred_date)
        if self.train_with_pred_feature and self.pred_feature_dict is not None:
            pred_feature_list = self.generate_pred_feature_list()
            train_pred_feature = data.loc[train_feature.index, pred_feature_list].dropna()
            train_pred_feature.columns = self.feature_list
            train_feature = pd.concat([train_feature, train_pred_feature], axis=0).sort_index()
            train_target = pd.concat([train_target, train_target[train_pred_feature.index]], axis=0).sort_index()
            train_feature = data.loc[train_feature.index, pred_feature_list].dropna()
            train_target = train_target[train_feature.index]
        return train_feature, train_target


    def fit(self, X_train, y_train):
        model = XGBRegressor()
        # print('train start time:', get_date(X_train.index.date[0]))
        # print('train end time:', get_date(X_train.index.date[-1]))
        # print('train days:', len(X_train)/self.points_per_day)
        if len(X_train) / self.points_per_day > self.cv - 0.5:
            cv = self.cv
        else:
            cv = int(len(X_train) / self.points_per_day)
        if cv == 1:
            model.fit(X_train, y_train)
            self.model = [model]
        else:
            cv_result = cross_validate(model, X_train, y_train, cv=cv, return_estimator=True)
            self.model = cv_result['estimator']

    def predict(self, X_test):
        model = self.model
        test_prediction = np.mean(np.array([submodel.predict(X_test) for submodel in model]).T, axis=1)
        test_prediction = np.clip(test_prediction, a_min=self.pred_min, a_max=self.pred_max)
        test_prediction[test_prediction < 0] = self.pred_min
        test_prediction = pd.Series(test_prediction, index=X_test.index)
        return test_prediction

