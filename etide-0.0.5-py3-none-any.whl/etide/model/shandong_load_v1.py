import numpy as np
import pandas as pd
from etide.model_pipeline import ModelBase
from xgboost import XGBRegressor


class LoadV1(ModelBase):
    """
    XGB负荷预测模型
    """

    def __init__(self,
                 feature_list,
                 target,
                 name='shandong_load_v2',
                 pred_feature_dict=None,
                 delay_days=None,
                 max_back_days=90,
                 pred_min=-9999999,
                 pred_max=9999999,
                 select_sample_func=False
                 ):
        super().__init__(
            name,
            feature_list,
            target,
            delay_days,
            max_back_days,
            pred_min,
            pred_max,
            pred_feature_dict
        )
        self.select_sample_func = select_sample_func
        self.model = None

    def build(self):
        self.model = XGBRegressor(objective='reg:squarederror', n_jobs=4, random_state=42, importance_type='gain',
                                  verbosity=0, n_estimators=100, max_depth=9, min_child_weight=0.9, subsample=1,
                                  reg_lambda=8, learning_rate=0.1)
        # self.model = XGBRegressor(objective='reg:linear', booster='gbtree', eval_metric='rmse', verbosity=0,
        #                           n_estimators=100, max_depth=8, min_child_weight=0.3, subsample=1, reg_lambda=4.8,
        #                           learning_rate=0.1, n_jobs=4, random_state=0)

    def fit(self, X_train, y_train):
        self.build()
        X_train = X_train.values
        y_train = y_train.values
        self.model.fit(X_train, y_train)

    def predict(self, X_test):
        test_index = X_test.index
        X_test = X_test.values
        y_pred = self.model.predict(X_test)
        y_pred = np.clip(y_pred, self.pred_min, self.pred_max)
        y_pred = pd.Series(y_pred, index=test_index)

        return y_pred
