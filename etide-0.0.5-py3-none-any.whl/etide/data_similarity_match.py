"""
电价预测模型滚动训练样本选取模块，包含相似日匹配功能
"""
import math
import logging
import numpy as np
import scipy.stats


logger = logging.getLogger(__name__)


def get_kde(x_array, data_array):
    res_list = []
    for x in x_array:
        bandwidth = 1.05 * np.std(data_array) * (len(data_array) ** (-1 / 5))

        def gauss(_x):
            return (1 / math.sqrt(2 * math.pi)) * math.exp(-0.5 * (_x ** 2))

        N = len(data_array)
        res = 0
        if len(data_array) == 0:
            return 0
        for i in range(len(data_array)):
            res += gauss((x - data_array[i]) / bandwidth)
        res /= (N * bandwidth)
        res_list.append(res)
    return res_list


def fb_dist(df_hist, df_pred, by='竞价空间', n_days=2):
    df_hist = df_hist.copy()
    df_pred = df_pred.copy()
    space_pred = df_pred[by].values

    def x_gen(a):
        return np.linspace(min(a), max(a), 100)

    x_array = x_gen(space_pred)
    space_ked = get_kde(x_array, space_pred)
    func = lambda x: scipy.stats.wasserstein_distance(x_gen(x.values),
                                                      x_array, get_kde(x_gen(x.values), x.values), space_ked)
    group_lib = df_hist.groupby(by='date').agg({by: func})
    price_space_sim = group_lib[by].sort_values()

    return price_space_sim[: n_days].index.tolist(), price_space_sim.values[: n_days]


def find_piece_data(lib_series, pred_array):
    """
    寻找历史日与预测日重合区间
    Args:
        lib_series: 历史数据
            Series
        pred_array: 预测数据
            array like

    Returns:
        select index
    """
    lib_series_min, lib_series_max = lib_series.min(), lib_series.max()
    pred_array_min, pred_array_max = pred_array.min(), pred_array.max()
    if lib_series_max >= pred_array_max:
        right = lib_series[lib_series >= pred_array_max].min()
    else:
        right = lib_series_max

    if lib_series_min <= pred_array_min:
        left = lib_series[lib_series <= pred_array_min].max()
    else:
        left = lib_series_min

    select_index = lib_series[(lib_series >= left) & (lib_series <= right)].index
    return select_index


def sample_select_v1(df_hist,
                     df_pred,
                     train_feature,
                     pred_feature,
                     select_days
                     ):
    """
    历史样本数据点选择模块V1，选取历史数据相似日
    :param df_hist: 历史数据，数据类型为dataframe，包含所有特征列和目标列，index为时间戳类型
    :param df_pred: 预测数据，数据类型为dataframe，包含所有特征列，index为时间戳类型
    :param train_feature: 训练特征col name，数据类型为string
    :param pred_feature: 预测特征col name，数据类型为string
    :param select_days: 样本选取天数，数据类型为int

    Returns: timestamps_train: 训练集选取时间戳

    """
    df_hist = df_hist.copy()
    df_pred = df_pred.copy()
    df_pred[train_feature] = df_pred[pred_feature]
    df_hist['date'] = df_hist.index.date
    dates_train = fb_dist(df_hist, df_pred, by=train_feature, n_days=select_days)[0]
    timestamps_train = df_hist[np.isin(df_hist.index.date, dates_train)].index
    return timestamps_train


def sample_select_v2(df_hist, df_pred, target, train_price_space, pred_price_space, price_max):
    """
    历史样本数据点选择模块V2，选取历史数据最近期全日数据，直到竞价空间上下限完全包含预测日竞价空间上下限
    :param df_hist: 历史数据，数据类型为dataframe，包含所有特征列和目标列，index为时间戳类型
    :param df_pred: 预测数据，数据类型为dataframe，包含所有特征列，index为时间戳类型
    :param target: 训练标签，数据类型为string
    :param train_price_space: 训练竞价空间col name，数据类型为string
    :param pred_price_space: 预测竞价空间col name，数据类型为string
    :param price_max: 电价上限，数据类型为float

    Returns: timestamps_train: 训练集选取时间戳

    """
    df_hist = df_hist.copy()
    df_pred = df_pred.copy()

    date_select_filter = sorted(np.unique(df_hist.index.date), reverse=True)

    price_space_pred = df_pred[pred_price_space].values
    select_price_space_max, select_price_space_min = None, None
    dates_train = []
    for i, d in enumerate(date_select_filter):
        if i == 0:
            dates_train.append(d)
        else:
            d_data = df_hist[np.isin(df_hist.index.date, dates_train + [d])]
            if d_data[train_price_space].values.max() > select_price_space_max or \
                    d_data[train_price_space].values.min() < select_price_space_min:
                dates_train.append(d)
            else:
                continue
        select_price_space = df_hist[np.isin(df_hist.index.date, dates_train)][train_price_space].values
        select_target = df_hist[np.isin(df_hist.index.date, dates_train)][target].values
        select_price_space_max = select_price_space.max()
        select_price_space_min = select_price_space.min()
        select_target_max = select_target.max()

        if (select_price_space_max >= price_space_pred.max() or select_target_max >= price_max) and \
                (select_price_space_min <= price_space_pred.min()):
            break
    timestamps_train = df_hist[np.isin(df_hist.index.date, dates_train)].index
    return timestamps_train
