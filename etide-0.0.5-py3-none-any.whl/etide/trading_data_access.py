"""
@author: zhenning.yang
@datetime: 2023/04/06 11:12
@desc: 从电力交易EDP数仓的DAAS服务api拉取数据模块
"""
import os
import yaml
import logging
import pandas as pd
from datetime import datetime
from dateutil.relativedelta import relativedelta
from poseidon import poseidon
from etide.utils import get_date
import etide.config

logger = logging.getLogger(__name__)
_cur_file = os.path.dirname(__file__)


def _read_config_info():
    """
    读取字段配置参数
    """
    config_file_path = os.path.abspath(os.path.join(_cur_file, './trading_data_field_config.yaml'))
    with open(config_file_path, 'r', encoding='utf-8') as f:
        config_info = yaml.load(f, Loader=yaml.FullLoader)
    return config_info


class DataLoaderEDP:

    def __init__(self,
                 daas_domain_name=etide.config.CONFIG_PARAM['daas_domain_name'],
                 access_key=etide.config.CONFIG_PARAM['daas_access_key'],
                 secret_key=etide.config.CONFIG_PARAM['daas_secret_key'],
                 province_config_info=None,
                 timeout=300
                 ):
        """
        初始化
        """
        self.daas_domain_name = daas_domain_name
        self.access_key = access_key
        self.secret_key = secret_key
        self.province_config_info = _read_config_info() if province_config_info is None else province_config_info
        self.timeout = timeout

    def get_province_code(self, province):
        """
        根据省份拼音获取省份编号
        :param province: 省份拼音，需与yaml文件中保持一致
        :return province_code: int Daas服务所需省份编码参数
        """
        try:
            province_code = self.province_config_info[province]['code']
            return province_code
        except:
            raise KeyError('不支持的省份')

    def get_province_field_map(self, province):
        """
        根据省份拼音获取所需字段以及映射中文名称dict
        :param province: 省份拼音，需与yaml文件中保持一致
        :return province_code: dict，Daas服务返回字段与中文名称映射关系
        """
        try:
            province_field_map = self.province_config_info[province]['field_map']
            return province_field_map
        except:
            raise KeyError('不支持的省份')

    def get_daas_data(self, url, if_change_time=True):
        """
        read data for poseidon
        url: string
            数据接口url
        return: DataFrame
        """
        data = pd.DataFrame()
        try:
            url = url.replace(" ", "%20")
            r = poseidon.urlopen(self.access_key, self.secret_key, url, timeout=self.timeout)
            data = pd.DataFrame(r['data'])
        except:
            logger.error('数据接口读取错误, 返回空DataFrame')
        if if_change_time:
            if len(data) > 0:
                if '00:15:00' in data['tradeTime'][0]:
                    data['tradeTime'] = data['tradeTime'].apply(
                        lambda x: pd.Timestamp(x[:10]) + pd.Timedelta(1, 'D') if x[-8:] == '24:00:00' else
                        pd.to_datetime(x))
                    data['tradeTime'] -= pd.Timedelta(15, 'min')
                else:
                    data['tradeTime'] = pd.to_datetime(data['tradeTime'])

        return data

    @staticmethod
    def rename_daas_data(data, field_map_dict, delay_days=None, if_change_time=True):
        """
        将DataFrame columns按照对应映射关系进行转换
        :param data: DataFrame
        :param field_map_dict: 字段映射dict，其中keys为df中原始的columns全集，values为映射后名称
        :param delay_days: int，trade day与publish day间隔天数
        :return: DataFrame，转换columns的DataFrame，index为时间戳
        """
        data_renamed = pd.DataFrame(columns=[
            'timestamp'
        ])
        if len(data) > 0:
            if delay_days is not None:
                data['publishDay'] = pd.to_datetime(data['publishDay'])
                data['deltaDay'] = (data['tradeTime'] - data['publishDay']).apply(lambda x: x.days)
                data = data[data['deltaDay'] == delay_days].sort_values('tradeTime', ignore_index=True)
            cols_all = field_map_dict.keys()
            cols_data_haven = list(filter(lambda x: x in data.columns, cols_all))
            data_renamed = data[cols_data_haven].rename(columns=field_map_dict)
        if if_change_time:
            data_renamed.set_index('timestamp', inplace=True)
        return data_renamed.dropna(axis=1, how='all')

    def read_clearing_price(self,
                            start_date,
                            end_date,
                            province,
                            node_id,
                            price_type='node',
                            site_id=''
                            ):
        """
        读取各个省份节点电价以及区域全省电价出清数据
        :param start_date: datetime，开始日期
        :param end_date: datetime，结束日期
        :param province: string，省份拼音
        :param node_id: string，节点名称
        :param price_type: str，province or node or area 分别代表节点、全省、区域电价，默认节点电价
        node_id与price_type的特例：
        蒙西 全网统一电价 node_id=mengxi price_type=province
        蒙西 呼保东电价 node_id=huBaoDong price_type=area
        蒙西 呼包西电价 node_id=huBaoXi price_type=area
        山西 统一结算点 node_id=shanxi price_type=province
        山西 电能量电价 node_id=energyPrice price_type=node
        :param site_id: string，场站id，只有甘肃需要此参数，用于获取场站上传实际出清电价数据
        :return: DataFrame，出清电价数据
        """
        start_date = get_date(start_date, return_type='str')
        end_date = get_date(end_date, shift_days=1, return_type='str')
        province_code = self.get_province_code(province)

        url = f'https://{self.daas_domain_name}/trading-terminal-api/v1/center-base/price-real/' \
              f'?provinceCode={province_code}&siteId={site_id}&name={node_id}&type={price_type}' \
              f'&tradeDay=&startDay={start_date}&endDay={end_date}'
        data = self.get_daas_data(url)
        real_price = self.rename_daas_data(data, self.get_province_field_map(province))
        return real_price

    def read_forecast_price(self,
                            start_date,
                            end_date,
                            province,
                            node_id,
                            delay_days,
                            price_type='node',
                            site_id=''
                            ):
        """
        读取各个省份日前和实时节点电价以及区域全省电价预测数据
        :param start_date: datetime，开始日期
        :param end_date: datetime，结束日期
        :param province: string，省份拼音
        :param node_id: string，节点名称
        :param delay_days: int，trade day与publish day间隔天数
        :param price_type: str，province or node or area 分别代表节点、全省、区域电价，默认节点电价
        :param site_id: string，场站id，只有甘肃需要此参数，用于获取场站预测电价数据
        :return: DataFrame，预测电价数据
        """
        start_date = get_date(start_date, return_type='str')
        end_date = get_date(end_date, shift_days=1, return_type='str')
        province_code = self.get_province_code(province)

        url = f'https://{self.daas_domain_name}/trading-terminal-api/v1/center-base/price-forecast/' \
              f'?provinceCode={province_code}&siteId={site_id}&name={node_id}&type={price_type}' \
              f'&publishDay=&tradeDay=&startDay={start_date}&endDay={end_date}'
        data = self.get_daas_data(url)
        forecast_price = self.rename_daas_data(data, self.get_province_field_map(province), delay_days=delay_days)
        return forecast_price

    def read_grid_supply_demand(self,
                                start_date,
                                end_date,
                                province,
                                delay_days=1,
                                site_id=''
                                ):
        """
        读取电网发布省级供需数据
        :param start_date: datetime or string，拉取数据开始时间
        :param end_date: datetime or string，拉取数据结束时间 左闭右闭
        :param end_date: datetime or string，拉取数据结束时间 左闭右闭
        :param province: string，省份拼音
        :param delay_days: int，trade day与publish day间隔天数，-1表示电网发布实时供需数据
        :param site_id: string，场站id，只有甘肃需要此参数，供需与场站绑定
        :return: DataFrame，电网发布供需数据
        """
        start_date = get_date(start_date, return_type='str', time_shift='00:15:00')
        end_date = get_date(end_date, shift_days=1, return_type='str', time_shift='00:15:00')
        province_code = self.get_province_code(province)

        url = f'https://{self.daas_domain_name}/trading-terminal-api/v1/center-base/net/suppl-demand/' \
              f'?provinceCode={province_code}&siteId={site_id}&publishDay=&tradeDay=&startTime={start_date}&endTime={end_date}'
        data = self.get_daas_data(url)
        grid_supply_demand = self.rename_daas_data(data, self.get_province_field_map(province), delay_days=delay_days)
        return grid_supply_demand

    def read_forecast_supply_demand(self,
                                    start_date,
                                    end_date,
                                    province,
                                    delay_days=1,
                                    site_id=''
                                    ):
        """
        读取自研算法预测省级供需数据
        :param start_date: datetime or string，拉取数据开始时间
        :param end_date: datetime or string，拉取数据结束时间 左闭右闭
        :param end_date: datetime or string，拉取数据结束时间 左闭右闭
        :param province: string，省份拼音
        :param delay_days: int，trade day与publish day间隔天数
        :param site_id: string，场站id，只有甘肃需要此参数，供需与场站绑定
        :return: DataFrame，算法预测供需数据
        """
        start_date = get_date(start_date, return_type='str')
        end_date = get_date(end_date, shift_days=1, return_type='str')
        province_code = self.get_province_code(province)

        url = f'https://{self.daas_domain_name}/trading-terminal-api/v1/center-base/forecast/supply-demand/' \
              f'?provinceCode={province_code}&siteId={site_id}&publishDay=&tradeDay=&startDay={start_date}&endDay={end_date}'
        data = self.get_daas_data(url)
        forecast_supply_demand = self.rename_daas_data(data, self.get_province_field_map(province),
                                                       delay_days=delay_days)
        return forecast_supply_demand

    def read_pub_forecast_supply_demand(self,
                                        publish_date,
                                        province,
                                        delay_days=None,
                                        site_id=''
                                        ):
        """
        根据发布日期读取自研算法预测省级供需数据
        :param publish_date: datetime or string，数据发布日期
        :param province: string，省份拼音
        :param delay_days: int，trade day与publish day间隔天数
        :param site_id: string，场站id，只有甘肃需要此参数，供需与场站绑定
        :return: DataFrame，算法预测供需数据
        """
        province_code = self.get_province_code(province)

        url = f'https://{self.daas_domain_name}/trading-terminal-api/v1/center-base/forecast/supply-demand/' \
              f'?provinceCode={province_code}&siteId={site_id}&publishDay={publish_date}&tradeDay=&startDay=&endDay='
        data = self.get_daas_data(url)
        forecast_supply_demand = self.rename_daas_data(data, self.get_province_field_map(province),
                                                       delay_days=delay_days).sort_index()
        return forecast_supply_demand

    def read_forecast_new_energy(self,
                                 start_date,
                                 end_date,
                                 province,
                                 ):
        """
        读取自研算法预测省级新能源预测数据,最长预测到D+60
        :param start_date: datetime or string，拉取数据开始时间
        :param end_date: datetime or string，拉取数据结束时间 左闭右闭
        :param province: string，省份拼音
        :return: DataFrame，算法预测供需数据
        """
        start_date = get_date(start_date, return_type='str')
        end_date = get_date(end_date, shift_days=1, return_type='str')
        province_code = self.get_province_code(province)

        url = f'https://{self.daas_domain_name}/trading-terminal-api/v1/forecast/latest-new-energy/' \
              f'?provinceCode={province_code}&startDay={start_date}&endDay={end_date}'
        data = self.get_daas_data(url)
        forecast_new_energy = self.rename_daas_data(data, self.get_province_field_map(province)).sort_index()

        return forecast_new_energy

    def read_typical_supply_demand_forecast(self,
                                            start_date,
                                            end_date,
                                            province,
                                            forecast_type='month',
                                            ):
        """
        读取典型供需均值预测，旬典型或月典型
        :param start_date: string，拉取数据开始时间, 如果是month输入2024-05 xun输入2024-05-01
        :param end_date: string，拉取数据结束时间 左闭右闭
        :param province: string，省份拼音
        :param forecast_type: string，预测类型 month与xun分别为月典型与旬典型
        :return: DataFrame，典型供需均值预测
        """
        province_code = self.get_province_code(province)
        if len(end_date) == 7:
            end_date = datetime.strptime(end_date, '%Y-%m')
            end_date = (end_date + relativedelta(months=1)).strftime('%Y-%m')
        else:
            end_date = datetime.strptime(end_date, '%Y-%m-%d')
            end_date = (end_date + relativedelta(days=1)).strftime('%Y-%m-%d')
        url = f'https://{self.daas_domain_name}/trading-terminal-api/v1/center-base/forecast/supply-demand-typical/' \
              f'?provinceCode={province_code}&type={forecast_type}&startTime={start_date}&endTime={end_date}'

        data = self.get_daas_data(url, if_change_time=False)
        if len(data) > 0:
            data = self.rename_daas_data(data, self.get_province_field_map(province), if_change_time=False)
            data['15min'] = data['15min'].apply(lambda x: x.split(':'))
            data['15min'] = data['15min'].apply(lambda x: (int(x[0]) * 60 + int(x[1])) // 15 - 1)

            if forecast_type == 'month':
                data = data.sort_values(['month', '15min'], ignore_index=True)
            else:
                data = data.sort_values(['tendays', '15min'], ignore_index=True)
        return data

    def read_typical_price_forecast(self,
                                    start_date,
                                    end_date,
                                    province,
                                    forecast_type='month',
                                    price_type='province',
                                    node_id='shanxi'
                                    ):
        """
        读取典型电价预测数据，旬典型或月典型
        :param start_date: string，拉取数据开始时间，如果是month输入2024-05 xun输入2024-05-01
        :param end_date: string，拉取数据结束时间 左闭右闭
        :param province: string，省份拼音
        :param forecast_type: string，预测类型 month与xun分别为月典型与旬典型
        :param price_type: string，province or node分别代表全省平均和节点电价，目前gansu支持节点
        :param node_id: string，当price_type为province，该参数必须为省份拼音，否则为node_id
        :return: DataFrame，典型电价预测数据
        """
        province_code = self.get_province_code(province)
        if len(end_date) == 7:
            end_date = datetime.strptime(end_date, '%Y-%m')
            end_date = (end_date + relativedelta(months=1)).strftime('%Y-%m')
        else:
            end_date = datetime.strptime(end_date, '%Y-%m-%d')
            end_date = (end_date + relativedelta(days=1)).strftime('%Y-%m-%d')

        url = f'https://{self.daas_domain_name}/trading-terminal-api/v1/center-base/forecast/price-typical/' \
              f'?provinceCode={province_code}&forecastType={forecast_type}&name={node_id}&priceType={price_type}' \
              f'&startTime={start_date}&endTime={end_date}'
        data = self.get_daas_data(url, if_change_time=False)

        if len(data) > 0:
            data = self.rename_daas_data(data, self.get_province_field_map(province), if_change_time=False)
            data['15min'] = data['15min'].apply(lambda x: x.split(':'))
            data['15min'] = data['15min'].apply(lambda x: (int(x[0]) * 60 + int(x[1])) // 15 - 1)

            if forecast_type == 'month':
                data = data.sort_values(['month', '15min'], ignore_index=True)
            else:
                data = data.sort_values(['tendays', '15min'], ignore_index=True)

        return data
