"""
包含模型滚动回测框架
"""
import logging
import pandas as pd
import traceback


logger = logging.getLogger(__name__)


class BackTestBase:
    """
    预测模型回测框架类模板，使用方法如下：
    backtest = BackTestBase()
    prediction = backtest.run(data)
    """
    def __init__(self,
                 start_date,
                 end_date,
                 interval,
                 model,
                 log_interval=1,
                 error_handler='ignore'
                 ):
        """
        模型回测框架初始化，生成测试日期列表
        :param start_date: 回测起始日期，数据类型为str，格式为%Y-%m-%d
        :param end_date: 回测结束日期，数据类型为str，格式为%Y-%m-%d
        :param interval: 回测滚动时间间隔，数据类型为str，有效取值如下：
                        当interval = ‘nD’，则表示按照每n天间隔进行滚动回测，n省略则默认为1天间隔，
                        当interval = ‘xun’，则表示按照旬进行滚动回测，测试日期为每旬的第一天，
                        当interval = 'month'，则表示按照月进行滚动回测，测试日期为每月的第一天
        :param model: model_pipeline.ModelBase对象 or list，支持多模型同时回测
        :param log_interval: 设置回测过程中回测日期的log间隔，数据类型为int，为0则表示不log回测日期
        :param error_handler: 指定在模型回测出错时的处理方式，"ignore":忽略错误并跳过当前模型回测过程，"raise":抛出错误并终止运行
        """
        self.start_date = start_date
        self.end_date = end_date
        self.interval = interval
        models = model if type(model) is list else [model]
        self.model = {model.name: model for model in models}
        if self.interval == 'month':
            test_dates = pd.date_range(self.start_date, self.end_date, freq='MS')
        elif self.interval == 'xun':
            dates = pd.date_range(self.start_date, self.end_date, freq='D')
            xun_label = pd.Series((dates.day - 1) // 10)
            xun_label[xun_label > 2] = 2
            test_dates = dates[xun_label != xun_label.shift()]
        else:
            test_dates = pd.date_range(self.start_date, self.end_date, freq=self.interval)
        test_dates = [test_date.strftime('%Y-%m-%d') for test_date in test_dates]
        self.test_dates = test_dates
        self.log_interval = log_interval
        self.error_handler = error_handler

    def get_model_name(self):
        """
        获取模型名
        :return: 模型名列表，数据类型为list
        """
        return list(self.model.keys())

    def set_model_params(self, params):
        """
        设置模型参数
        :param params: 模型参数，数据类型为dict，格式为{'model_name':{'model_param_name':model_param}}
        :return:
        """
        for model_name in params:
            if model_name in self.model:
                logger.info(f'set {model_name} parameters')
                self.model[model_name].set_model_params(params[model_name])

    def run(self, data):
        """
        回测过程运行函数
        :param data: 回测数据集，数据类型为DataFrame，index为时间戳类型
        :return: 回测
        """
        logger.info('back test start running')
        prediction = []
        for i, test_date in enumerate(self.test_dates):
            if self.log_interval > 0 and i % self.log_interval == 0:
                logger.info(f'test date:{test_date}')
            prediction_per_test_date = pd.DataFrame()
            for name in self.model:
                if self.log_interval > 0 and i % self.log_interval == 0:
                    logger.info(f'test model:{name}')
                try:
                    prediction_per_model = self.model[name].run(data, test_date)
                except:
                    logger.error(traceback.format_exc())
                    logger.error('model run fail')
                    if self.error_handler == 'ignore':
                        continue
                    else:
                        raise Exception
                if isinstance(prediction_per_model, pd.Series):
                    prediction_per_test_date[name] = prediction_per_model
                elif isinstance(prediction_per_model, pd.DataFrame):
                    for c in prediction_per_model.columns:
                        prediction_per_test_date[name+'_'+c] = prediction_per_model[c]
                else:
                    logger.error(f'invalid prediction result from model {name}')
            prediction.append(prediction_per_test_date)
        prediction = pd.concat(prediction)
        logger.info('back test finish running')
        return prediction
