"""
code template
"""

def function_template(arg_1, arg_2):
    """
    function description
    :param arg_1: data type, shape, value range, description
    :param arg_2: data type, shape, value range, description
    :return: data type, shape, description
    """
    pass

class ClassTemplate:
    """
    class description, should explain the typical workflow of the class, for example:
    obj = ClassTemplate()
    obj.fit(data)
    prediction = obj.predict(data)
    """

    def __init__(self, arg_1, arg_2):
        """
        refer to function_template
        """
        pass

    def class_function_template(self, arg_1, arg_2):
        """
        refer to function_template
        """
        pass
