"""
@author: zhenning.yang
@datetime: 2023/10/25 11:04
@desc: 从数仓读取配置参数
"""
import os
import pymysql
import pandas as pd
import logging
import traceback


logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
stream_handler = logging.StreamHandler()
stream_handler.setLevel(level=logging.INFO)
logger.addHandler(stream_handler)


database_config = dict(host=os.environ.get('tt_algo_host', "10.65.30.13"),
                       port=int(os.environ.get('tt_algo_port', 3306)),
                       database=os.environ.get('tt_algo_database', "algo"),
                       user=os.environ.get('tt_algo_user', "envuser"),
                       password=os.environ.get('tt_algo_password', "Envisi0n@321!"),
                       charset=os.environ.get('tt_algo_charset', "utf8")
                       )


class ConfigParam(dict):
    def __init__(self, *args, **kwargs):
        self.default_config = {
            'daas_domain_name': "app-portal-cn-ft.enos-iot.com",
            'daas_access_key': "287ec074-4b01-43d8-848b-ff2451586b16",
            'daas_secret_key': "8c39f897-9371-40c9-b6c7-fac93d741d85",
        }
        super().__init__(*args, **kwargs)

    def __missing__(self, key):
        return self.default_config.get(key)


CONFIG_PARAM = ConfigParam()


def set_config_param():
    """
    read config params from database
    run this function at your project main py first
    """
    logger.info('数据库配置为%s' % database_config)
    try:
        db_connect = pymysql.connect(**database_config)
        param_df = pd.read_sql(f"select * from tt_algo_config_param", db_connect)
        db_connect.close()
        param_dict = {}
        for i in range(len(param_df)):
            param_dict.update({param_df.loc[i, 'name']: param_df.loc[i, 'value']})
        param_dict.update({'database_config': database_config})
        global CONFIG_PARAM
        CONFIG_PARAM = ConfigParam(param_dict)
        logger.info(f'读取数据库配置参数:{param_dict}')
        logger.info('读取数据库配置参数成功')
    except:
        logger.error(traceback.format_exc())
        logger.error('读取数据库配置参数失败')
