"""
包含一些通用功能模块
"""
import numpy as np
import pandas as pd
import datetime
import pytz


def get_date(ref_date=None, shift_days=0, return_type='str', time_shift=None):
    """
    基于参考日期和偏移量获取目标日期
    :param ref_date: 指定参考日期，数据类型为None或者str或者datetime.datetime或者datetime.date或者pd.Timestamp，
            如果为None，则取当前日期，
            如果为str，格式为yyyy-mm-dd，
            为datetime.datetime或者pd.Timestamp时只取其日期部分
    :param shift_days: 指定日期偏移量，单位为天，返回目标日期等于参考日期+日期偏移量
    :param return_type: 指定返回目标日期的数据类型，可以取值"str"或者"timestamp"或者"datetime"
    :param time_shift: 返回目标日期中的时间偏移量，数据类型为None或者str，
                       如果为None，则返回目标日期中不包含时间偏移量
                       如果为str，则格式为hh[:mm][:ss]，返回目标日期中加上该时间偏移量
    :return: 返回目标日期，数据类型为"str"或者"timestamp"或者"datetime"
    """
    if ref_date is None:
        ref_date = datetime.datetime.now(tz=pytz.timezone('Asia/Shanghai')).date()
    elif isinstance(ref_date, datetime.datetime):
        ref_date = ref_date.date()
    elif isinstance(ref_date, datetime.date):
        ref_date = ref_date
    elif isinstance(ref_date, pd.Timestamp):
        ref_date = str(ref_date.date())
        ref_date = datetime.datetime.strptime(ref_date, '%Y-%m-%d')
    elif isinstance(ref_date, str):
        ref_date = datetime.datetime.strptime(ref_date, '%Y-%m-%d')
    return_date = ref_date + datetime.timedelta(days=shift_days)
    return_date = return_date.strftime("%Y-%m-%d")
    if time_shift is not None:
        return_date = return_date + ' ' + time_shift
    if return_type == 'timestamp':
        return_date = pd.Timestamp(return_date)
    elif return_type == 'datetime':
        return_date = pd.Timestamp(return_date).to_pydatetime()
    return return_date


def _transform_typical(data, typical_length=96):
    """
    将输入序列转成典型值
    :param data: 输入数据，数据类型为dataframe或者series，如果为dataframe，则对其每一列进行典型值转换
    :param typical_length: 指定典型值序列长度，默认为一天96点
    :return: 返回典型值，数据类型和输入数据data数据类型一致
    """
    if isinstance(data, pd.DataFrame):
        columns = data.columns
        num_cols = len(columns)
        typical_data = pd.DataFrame(np.nanmean(data.values.reshape(-1, typical_length, num_cols), axis=0),
                                    columns=columns)
    else:
        typical_data = pd.Series(np.nanmean(data.values.reshape(-1, typical_length), axis=0), name=data.name)
    typical_data.index = data.index[:typical_length]
    return typical_data


def transform_typical(data, typical_type=None, typical_length=96):
    """
    将输入序列转成典型值，支持月典型和旬典型
    :param data: 输入数据，数据类型为dataframe或者series，index为时间戳类型，如果为dataframe，则对其每一列进行典型值转换
    :param typical_type: 指定典型值类型，
                如果为"month"，则转换为月典型，如果输入数据时间范围包括多月则将每个月的月典型值按顺序连接起来
                如果为"xun"，则转换为旬典型，如果输入数据时间范围包括多旬则将每个旬的旬典型值按顺序连接起来
                如果为None，则将输入序列整体转换为一个典型值序列
    :param typical_length: 指定典型值序列长度，默认为一天96点
    :return: 返回典型值，数据类型和输入数据data数据类型一致
    """
    if typical_type == 'month':
        typical_data = data.resample('M').apply(lambda x: _transform_typical(x, typical_length))
        typical_data.index = typical_data.index.droplevel()
    elif typical_type == 'xun':
        xun_label = pd.Series((data.index.day - 1) // 10, index=data.index)
        xun_label[xun_label > 2] = 2
        typical_data = data.groupby((xun_label != xun_label.shift()).cumsum()).apply(
            lambda x: _transform_typical(x, typical_length))
        typical_data.index = typical_data.index.droplevel()
    else:
        typical_data = _transform_typical(data, typical_length)
    return typical_data


def select_interval(data, interval):
    """
    对输入数据每天按照时刻区间进行选取，例如当interval=[7,16]时，则将每天7:00(包含)至16:00(不包含)时间范围内的数据筛选出来
    :param data: 输入数据，Series或者DataFrame，index必须为timestamp类型
    :param interval: 时间选取范围，integer(只取每天某一个小时的数据，大于等于0且小于24) or list of two integers(大于等于0且小于等于24)
    :return: 返回筛选后的数据
    """
    data_out = []
    for day, data_group in data.resample('1D'):
        if not isinstance(interval, list):
            if interval < 10:
                start_time = '0' + str(interval)
            else:
                start_time = str(interval)
            start_time = str(day.date()) + ' ' + start_time
            data_out.append(data.loc[start_time])
        else:
            start_time = interval[0]
            end_time = interval[1] - 1
            if start_time < 10:
                start_time = '0' + str(start_time)
            else:
                start_time = str(start_time)
            if end_time < 10:
                end_time = '0' + str(end_time)
            else:
                end_time = str(end_time)
            start_time = str(day.date()) + ' ' + start_time
            end_time = str(day.date()) + ' ' + end_time
            data_out.append(data.loc[start_time:end_time])
    data_out = pd.concat(data_out)
    return data_out


if __name__ == '__main__':
    # test get_date
    _return_date = get_date(ref_date=pd.Timestamp('2023-01-01'), shift_days=0,
                            return_type='str', time_shift='00:15')
    print(_return_date)
    print(type(_return_date))

    # test transform_typical
    data_len = 102
    _data = (np.arange(0, data_len).reshape(-1, 1) + np.arange(0, 96).reshape(1, -1)).ravel()
    _data = np.c_[_data, _data + 1]
    _data = pd.DataFrame(_data, index=pd.date_range('2023-01-01', freq='15min', periods=96 * data_len))
    _typical_data = transform_typical(_data, typical_type='month', typical_length=96)
    print(_data)
    print(_typical_data)
