import time
import traceback
import pandas as pd
import numpy as np
from loguru import logger
from scipy.interpolate import interp1d

from kong_sdk.weather_source import get_weather_sequence
from kong_sdk.weather_source_irra import get_ghi_poa_irradiance
from kong_sdk import environment_configuration

environment_configuration('prod-cn5', zipkin_default_sample_rate=0)
# environment_configuration('pdc', zipkin_default_sample_rate=0)


class PullWeatherForecastKM(object):
    """
    基于kong_sdk拉取15min级别气象预报
    """

    def __init__(self, location: dict, attribute: dict, timezone='Asia/Shanghai', get_mean=True, weights=None,
                 forecast_hour=8):
        """
        参数初始化
        :param location: dict，坐标字典 {"point_1": {"lon": 105.573, "lat": 38.607},}
        :param attribute: dict，气象源及气象属性字典 {'ENS_AVG': ['TMP', 'WS', 'WD', 'PRES', 'ghi', 'poai'], 'GFS': ['RH']}
        :param timezone: str，原始数据为UTC+0时区，根据需要转换为对应时区，默认'Asia/Shanghai'（UTC+8）
        :param get_mean: bool，True为保留所有点平均气象预报
        :param weights: list，按照坐标顺序进行加权平均
        :param forecast_hour: int，D日预测时间，内部会根据预测时间自动获取最近的预报
        """
        self.location = location
        self.attribute = attribute
        self.timezone = timezone

        self.get_mean = get_mean
        self.weights = weights
        self.forecast_hour = forecast_hour
        self.update_hour = [4, 16]  # kong_sdk在上午4点左右更新昨日20点预报（对应UTC时间D-1日12点），下午4点左右更新今日8点预报（对应UTC时间D日0点）
        self.publish_hour = 12 if self.update_hour[0] < self.forecast_hour - 0.5 < self.update_hour[-1] else 0
        self.publish_toggle_hour = 12  # 发布序列小于该时刻时,dn_offset需要加1
        self.nwp_len_dict = {'EC': 3, 'GFS': 10, 'ENS_AVG': 15, 'AI_WEATHER1': 10, 'AI_WEATHER2': 15}

        self.debug = False  # 打印报错信息，用于线下调试
        self.resample = False

    def get_single_point_forecast(self, lat, lon, pull_date, pull_offset, save_days=1):
        """
        获取指定经纬度点15min颗粒度的气象预报
        :param lat: 纬度
        :param lon: 经度
        :param pull_date: 数据拉取时间（指代发布时间）
        :param pull_offset: 数据拉取偏移天数
        :param save_days: 保留天数,至少1天
        :return: 指定经纬度的(pull_date + pull_offset) ~ (pull_date + pull_offset + save_days - 1)的15min气象预报
        """
        '预测长度校验'
        pull_days = pull_offset + save_days
        if pull_offset <= 0 or save_days <= 0:
            raise Exception('pull_offset与save_days至少为1天')

        nwp_len_min = min([self.nwp_len_dict[k] for k in self.attribute.keys()])
        if pull_days > nwp_len_min:
            raise Exception(f'所用气象源最长预报{nwp_len_min}天')

        '建立时间戳'
        pull_date = pull_date + pd.Timedelta(hours=self.publish_hour)
        timestamps = pd.date_range(pull_date, pull_date + pd.Timedelta(days=pull_days, seconds=-1), freq='15min')
        w_df = pd.DataFrame(timestamps, columns=['timestamp'])
        w_df['publish_date'] = pull_date

        '拉取气象数据'
        for nwp, pull_param in self.attribute.items():
            w_param = [p for p in pull_param if p not in ['ghi', 'poai']]  # 非辐照类气象属性
            i_param = [p for p in pull_param if p in ['ghi', 'poai']]  # 辐照类气象属性

            '拉取非辐照类气象预报,原始颗粒度为1h,线性插值至15min,多拉取一个点用于插值'
            for param in w_param:
                raw_data = \
                get_weather_sequence(lat, lon, nwp, param, pull_date, 1, hours=(pull_days * 24 + 1), offset=0)[0]
                n = len(raw_data)

                if param in ['RAINFALL']:
                    raw_data = raw_data * 1000

                if not self.resample:
                    raw_data_new = np.interp(np.arange(0, n, 0.25), np.arange(0, n, 1), raw_data)[:pull_days * 96]
                elif pull_days <= 3:
                    raw_data_new = interp1d(np.arange(0, n, 1), raw_data[::1], kind='quadratic')(
                        np.arange(0, n - 1, 0.25))[:pull_days * 96]
                elif pull_days <= 6:
                    raw_data_1 = interp1d(np.arange(0, n, 1), raw_data[::1], kind='quadratic')(
                        np.arange(0, n - 1, 0.25))[:pull_days * 96]
                    raw_data_2 = interp1d(np.arange(0, n, 2), raw_data[::2], kind='quadratic')(
                        np.arange(0, n - 1, 0.25))[:pull_days * 96]
                    raw_data_new = np.concatenate((raw_data_1[: 3 * 96], raw_data_2[3 * 96:]), axis=0)
                else:
                    raw_data_1 = interp1d(np.arange(0, n, 1), raw_data[::1], kind='quadratic')(
                        np.arange(0, n - 1, 0.25))[:pull_days * 96]
                    raw_data_2 = interp1d(np.arange(0, n, 3), raw_data[::3], kind='quadratic')(
                        np.arange(0, n - 1, 0.25))[:pull_days * 96]
                    raw_data_3 = interp1d(np.arange(0, n, 6), raw_data[::6], kind='quadratic')(
                        np.arange(0, n - 1, 0.25))[:pull_days * 96]
                    raw_data_new = np.concatenate(
                        (raw_data_1[: 3 * 96], raw_data_2[3 * 96: 6 * 96], raw_data_3[6 * 96:]), axis=0)

                w_df[f'{nwp}.{param}'] = raw_data_new

            '拉取辐照类气象预报,原始颗粒度选取15min级别'
            if len(i_param) > 0:
                # kong_sdk 1.1.1.2 bug修复, 辐照函数中hours∉[144, 152]
                i_pull_days = pull_days + 1 if pull_days == 6 else pull_days
                raw_data = get_ghi_poa_irradiance({'lat': lat, 'lon': lon, 'altitude': 30},
                                                  {'array_tilt': 30, 'array_azimuth': 180},
                                                  pull_date, nwp, '15min', hours=i_pull_days * 24, offset=0)
                raw_data = raw_data.reset_index()
                raw_data.columns = ['publish_date', 'timestamp', f'{nwp}.ghi', f'{nwp}.poai']
                for param in i_param:
                    w_df[f'{nwp}.{param}'] = raw_data[f'{nwp}.{param}'].iloc[:pull_days * 96, ].values

        '空值检测'
        if w_df.drop(columns=['timestamp', 'publish_date']).isnull().all().all():
            raise Exception('data is empty')

        '数据时区转换'
        for time_col in ['timestamp', 'publish_date']:
            w_df[time_col] = w_df[time_col].dt.tz_localize('UTC').dt.tz_convert(self.timezone)
            w_df[time_col] = pd.to_datetime(w_df[time_col].dt.strftime("%Y-%m-%d %H:%M:%S"))

        '日期截断'
        data_sta = pull_date + pd.Timedelta(days=pull_offset, hours=-self.publish_hour)
        data_end = data_sta + pd.Timedelta(days=save_days)
        w_df = w_df.loc[(w_df['timestamp'] >= data_sta) & (w_df['timestamp'] < data_end)].reset_index(drop=True)

        format_list = [col for col in w_df.columns if col not in ['timestamp', 'publish_date']]
        w_df[format_list] = w_df[format_list].round(2)

        return w_df

    def get_multiple_point_forecast(self, pull_date, pull_offset, save_days=1):
        """
        获取多个经纬度点15min颗粒度气象预报
        :param pull_date: 数据拉取时间（指代发布时间）
        :param pull_offset: 数据拉取偏移天数
        :param save_days: 保留天数,至少1天
        :return: 经纬度字典的(pull_date + pull_offset) ~ (pull_date + pull_offset + save_days - 1)的15min气象预报
        """
        multi_df = pd.DataFrame()
        '获取多点预报'
        update_time = pull_date + pd.Timedelta(hours=self.publish_hour)  # 转换至相应时区
        update_time = update_time.tz_localize('UTC').tz_convert(self.timezone)
        update_time = pd.to_datetime(update_time.strftime("%Y-%m-%d %H:%M:%S"))

        for name, loc in self.location.items():
            try:  # 单点数据缺失就跳过
                single_df = self.get_single_point_forecast(loc['lat'], loc['lon'], pull_date, pull_offset, save_days)
                name_list = single_df.columns.tolist()
                single_df.columns = name_list[:2] + [f'{name}.{n}' for n in name_list[2:]]
                multi_df = single_df if multi_df.empty else pd.merge(multi_df, single_df, on=name_list[:2], how='outer')
            except:
                if self.debug:
                    logger.warning(traceback.print_exc())
                logger.warning(f'{name} {update_time}发布气象预报获取失败！')

        if multi_df.empty or multi_df.drop(columns=['timestamp', 'publish_date']).empty:
            logger.error(f'{update_time}发布气象预报获取失败！')
            return pd.DataFrame()

        '对多点预报做平均'
        if self.get_mean:
            name_list = multi_df.columns.tolist()
            save_list = name_list[:2]
            for nwp, params in self.attribute.items():
                for p in params:
                    check_str = f'{nwp}.{p}'
                    save_list.append(check_str)
                    use_cols = [c for c in name_list if check_str in c]
                    multi_df[check_str] = np.average(multi_df[use_cols], axis=1, weights=self.weights).round(2)
            multi_df = multi_df[save_list]
        logger.info(f'{update_time}发布气象预报获取成功！')

        return multi_df

    def get_pub_weather_forecast(self, pub_sta, pub_end, offset: int, save_days=1, drop_pub=True):
        """
        根据发布日（P）获取气象预报,日期左闭右闭
        :param pub_sta: 发布起始日期
        :param pub_end: 发布结束日期
        :param offset: 从发布日后offset天开始截取
        :param save_days: 保留（P + offset） ~ （P + offset + save_days - 1）的日期的数据
        :param drop_pub: 移除发布时间列
        :return: 发布日期pub_sta ~ pub_end的气象源（P + offset） ~ （P + offset + save_days - 1）的15min级别预报数据
        """
        pull_dates = pd.date_range(pub_sta, pub_end, freq='1d')

        pub_df = pd.DataFrame()
        for d in pull_dates:
            temp_df = self.get_multiple_point_forecast(pull_date=d, pull_offset=offset, save_days=save_days)
            pub_df = pd.concat([pub_df, temp_df], ignore_index=True)

        if not pub_df.empty:
            pub_df = pub_df.drop_duplicates(subset=['publish_date', 'timestamp'], keep='last')
            pub_df = pub_df.sort_values(by=['publish_date', 'timestamp'])

            if drop_pub:
                if 'publish_date' in pub_df.columns:
                    pub_df = pub_df.drop(columns=['publish_date'])

        return pub_df

    def get_dn_weather_forecast(self, sta_date, end_date, dn_offset: int):
        """
        获取D+N的预测结果,日期左闭右闭
        :param sta_date: D+N预报起始日期
        :param end_date: D+N预报结束日期
        :param dn_offset: int, [1, 13]获取D日发布的第D+offset天的气象预报
        :return: D+N的sta_date ~ end_date的15min级别气象预报
        """
        '判断预测场景'
        if self.publish_hour >= self.publish_toggle_hour:
            dn_offset += 1

        pub_sta = sta_date - pd.Timedelta(f'{dn_offset}d')
        pub_end = end_date - pd.Timedelta(f'{dn_offset}d')

        dn_pred = self.get_pub_weather_forecast(pub_sta, pub_end, dn_offset, save_days=1, drop_pub=True)

        return dn_pred

    def update_dn_weather_forecast(self, hist_df, dn_offset: int, update_end=None):
        """
        更新D+N的预测结果,用于线上更新本地数据
        :param hist_df: 历史预测结果
        :param update_end: 数据更新的日期
        :param dn_offset: 获取D日发布的第D+offset天的气象预报
        :return: D+N更新后的15min级别气象预报
        """
        spot_time = pd.Timestamp(time.strftime('%Y-%m-%d %H:%M:%S%z')).tz_convert(self.timezone)
        spot_date = pd.Timestamp(spot_time.strftime('%Y-%m-%d'))

        '参数校验'
        if update_end is None:
            update_end = spot_date + pd.Timedelta(days=dn_offset)
            if spot_time.hour < self.update_hour[-1] and self.publish_hour < self.publish_toggle_hour:
                update_end -= pd.Timedelta(days=1)
        elif update_end > spot_date + pd.Timedelta(days=dn_offset):
            Exception('预测日数据未发布')

        '数据读取'
        hist_end = hist_df['timestamp'].dt.date.max()
        if hist_end >= update_end:
            logger.info('气象数据已包含预测日!')
        else:
            logger.info('气象数据开始更新!')
            update_df = self.get_dn_weather_forecast(sta_date=hist_end + pd.Timedelta(days=1),
                                                     end_date=update_end,
                                                     dn_offset=dn_offset)
            '数据去重合并'
            hist_df = pd.concat([hist_df, update_df], ignore_index=True)
            hist_df = hist_df.drop_duplicates('timestamp', keep='last')

            update_end = hist_df['timestamp'].dt.date.max()
            logger.info(f'气象数据已更新至{update_end}')

        return hist_df

    def get_lastest_weather_forecast(self, pub_date=None, dn_offset=None):
        """
        获取最新发布的未来14天的气象预报或者指定日期（D日）发布的气象预报
        :param pub_date: pd.Timestamp, 不指定发布日期就是当前日期
        :param dn_offset: int, 0~14, 根据发布日期截取指定的D+dn_offset预报
        :return: 上午获取为(D) ~ （D + 13）预报，下午获取的为（D + 1） ~ （D + 14）预报
        """
        spot_time = pd.Timestamp(time.strftime('%Y-%m-%d %H:%M:%S%z')).tz_convert(self.timezone)
        spot_date = pd.Timestamp(spot_time.strftime('%Y-%m-%d'))

        '缓存设置'
        temp_pub_hour = self.publish_hour

        '日期校验'
        if pub_date is None:
            pub_date = spot_date
            self.publish_hour = 12 if spot_time.hour < self.update_hour[-1] else 0
        elif pd.Timestamp(pub_date) > pd.Timestamp(spot_date):
            raise Exception('未来日数据未发布')

        '最近序列获取'
        save_days = min([self.nwp_len_dict[k] for k in self.attribute.keys()]) - 1
        if self.publish_hour >= self.publish_toggle_hour:
            pub_date -= pd.Timedelta(days=1)
        pub_df = self.get_pub_weather_forecast(pub_date, pub_date, offset=1, save_days=save_days, drop_pub=True)

        '日期截断'
        if dn_offset is not None:
            dn_offset = dn_offset + 1 if self.publish_hour < self.update_hour[-1] else dn_offset
            pub_df = pub_df.loc[(pub_df['timestamp'] - pub_date).dt.days == dn_offset]

        '设置还原'
        self.publish_hour = temp_pub_hour

        return pub_df

    def get_weather_from_diff_pub(self, sta_date, end_date, dn_offset, utc_list=[12, 18, 0]):
        """
        获取EC和GFS的不同时间气象预报
        :param sta_date: D+N预报起始日期
        :param end_date: D+N预报结束日期
        :param dn_offset: int, [1, 13]获取D日发布的第D+offset天的气象预报
        :param utc_list: 气象源发布UTC时间列表
        :return: D+N的sta_date ~ end_date的15min级别气象预报
        """
        temp_pub_hour = self.publish_hour

        merge_df = pd.DataFrame()
        for pub_hour in utc_list:
            self.publish_hour = pub_hour
            w_df = self.get_dn_weather_forecast(sta_date, end_date, dn_offset)
            if not w_df.empty:
                w_df.columns = ['timestamp'] + [f'{col}_UTC{pub_hour}' for col in w_df.columns.tolist()[1:]]
                merge_df = w_df if merge_df.empty else pd.merge(merge_df, w_df, on=['timestamp'], how='outer')

        self.publish_hour = temp_pub_hour

        return merge_df

    def get_multi_dn_weather_forecast(self, sta_date, end_date, dn_list: list):
        """
        拉取不同的D+N数据,通过publish_date和timestamp区分
        :param sta_date: pd.Timestamp, D+N预报起始日期
        :param end_date: pd.Timestamp, D+N预报结束日期
        :param dn_list: 偏移量列表
        :return: D+N的sta_date ~ end_date的15min级别气象预报
        """
        '判断预测场景'
        offset = 1 if self.publish_hour >= self.publish_toggle_hour else 0
        dn_min = min(dn_list) + offset
        dn_max = max(dn_list) + offset

        pub_df = self.get_pub_weather_forecast(pub_sta=sta_date - pd.Timedelta(days=dn_max),
                                               pub_end=end_date - pd.Timedelta(days=dn_min),
                                               offset=dn_min, save_days=(dn_max - dn_min + 1),
                                               drop_pub=False)

        pub_df['publish_date'] = pd.to_datetime(pub_df['publish_date'].dt.date + pd.Timedelta(days=offset))

        return pub_df

    def get_all_pub_weather_forecast(self, pub_sta, pub_end):
        """
        发布的所有数据,通过publish_date和timestamp区分
        :param pub_sta: pd.Timestamp, D+N预报起始日期
        :param pub_end: pd.Timestamp, D+N预报结束日期
        :return: D+N的sta_date ~ end_date的15min级别气象预报
        """
        '判断预测场景'
        pub_offset = 1 if self.publish_hour >= self.publish_toggle_hour else 0

        save_days = min([self.nwp_len_dict[k] for k in self.attribute.keys()]) - 1

        pub_df = self.get_pub_weather_forecast(pub_sta=pub_sta - pd.Timedelta(days=pub_offset),
                                               pub_end=pub_end - pd.Timedelta(days=pub_offset),
                                               offset=1, save_days=save_days, drop_pub=False)
        pub_df['publish_date'] = pd.to_datetime(pub_df['publish_date'].dt.date + pd.Timedelta(days=pub_offset))

        return pub_df


if __name__ == '__main__':
    """
    说明：
    kong_sdk环境迁移情况：https://wiki.eniot.io/pages/viewpage.action?pageId=49494068
    kong_sdk安装环境：pip install packages/kong_sdk-1.1.1.2-py3-none-any.whl
    目前已知kong_sdk-1.1.1.2中辐照拉取函数get_ghi_poa_irradiance不能设置拉取长度为6天（即hours∉[144, 152]），该问题在拉取中修复
    kong_sdk使用环境：cn5环境下使用设置为'prod-cn5'，本地使用环境设置为'pdc'
    kong_sdk气象源更新时间：每天北京时间4:30左右更新D-1日20点气象预报，16:30左右更新D日8点气象预报
    kong_sdk气象源历史起始发布日期：ENS_AVG（2021-11-01），EC（2021-04-01），GFS（2021-04-01）
    kong_sdk气象源预测长度：ENS_AVG（预报15天），EC（预报3天），GFS（预报10天）
    kong_sdk气象源预测类型：以上气象源均支持TMP（温度），WS（风速），WD（风向），PRES（气压），ghi（辐照强度），poai（阵列点辐照强度），
    RAINFALL(降雨量)，PTYPE（气象类型，0无降雨1降雨3冻雨5降雪6融雪7雨夹雪8冰雹）
    GFS支持RH（相对湿度中），CAMS_EXTENDED支持DAOD(沙尘)，HRES_ICE2支持MICE(结冰质量)
    """

    # 地点坐标必须为以下示例格式，point_1为地点名称标识，可以根据需要调整,示例为山东网格数据
    loc_dict = {
        'point_0': {'lon': 115.819, 'lat': 35.377},
        'point_1': {'lon': 116.819, 'lat': 35.377},
        'point_2': {'lon': 117.819, 'lat': 35.377},
        'point_3': {'lon': 118.819, 'lat': 35.377},
        'point_4': {'lon': 115.819, 'lat': 36.377},
        'point_5': {'lon': 116.819, 'lat': 36.377},
        'point_6': {'lon': 117.819, 'lat': 36.377},
        'point_7': {'lon': 118.819, 'lat': 36.377},
        'point_8': {'lon': 119.819, 'lat': 36.377},
        'point_9': {'lon': 116.819, 'lat': 37.377},
        'point_10': {'lon': 117.819, 'lat': 37.377},
        'point_11': {'lon': 118.819, 'lat': 37.377},
        'point_12': {'lon': 120.819, 'lat': 37.377},
        'point_13': {'lon': 121.819, 'lat': 37.377},
    }

    # kong_sdk支持的气象属性列表，注意可拉取长度
    att_dict = {
        # 'ENS_AVG': ['TMP', 'WS', 'WD', 'PRES', 'RAINFALL', 'PTYPE', 'ghi', 'poai'],  # 最长15天（小时级别361点）
        # 'EC': ['TMP', 'WS', 'WD', 'PRES', 'RAINFALL', 'PTYPE', 'ghi', 'poai'],  # 最长3天（小时级别73点）
        # 'GFS': ['TMP', 'WS', 'WD', 'PRES', 'RH', 'ghi', 'poai'],  # 最长10天（小时级别241点）
        # 'CAMS_EXTENDED': ['DAOD'], # 最长5天（小时级别121点）
        # 'HRES_ICE2': ['MICE'], #
        # 'AI_WEATHER1': ['TMP', 'WS', 'WD', 'PRES'],  # 最长10天（小时级别241点）
        # 'AI_WEATHER2': ['WS', 'WD'],  # 最长15天（小时级别361点）
    }
    # att_dict = {'ENS_AVG': ['TMP', 'WS', 'WD', 'PRES', 'RAINFALL', 'ghi', 'poai'], 'GFS': ['RH']}
    att_dict = {'AI_WEATHER1': ['TMP', 'WS', 'WD', 'PRES'], 'AI_WEATHER2': ['WS', 'WD']}

    # 主要功能
    PWF = PullWeatherForecastKM(location=loc_dict,
                                attribute=att_dict,
                                timezone='Asia/Shanghai',
                                get_mean=True,  # 为True时只保留所有点平均预报
                                forecast_hour=8,  # [0, 3]采用D-1日8点起始预报，[4, 16]采用D-1日20点起始预报，[17, 23]采用D日8点起始预报
                                )

    # 获取D+dn_offset场景下 sta_date~end_date的气象数据，时间为左闭右闭
    # hist_data = PWF.get_dn_weather_forecast(sta_date=pd.Timestamp('2023-08-01'),
    #                                         end_date=pd.Timestamp('2023-08-01'),
    #                                         dn_offset=8)

    # # 更新D+dn_offset场景历史数据至最新
    # update_data = PWF.update_dn_weather_forecast(hist_data, dn_offset=1)
    #
    # 获取当前时刻发布未来14天的最新气象预报,通过dn_offset可以截取指定日期
    # pred_data = PWF.get_lastest_weather_forecast()
    # pred_data = PWF.get_lastest_weather_forecast(pub_date='2023-06-01')

    # 获取D+N的不同时刻更新的气象预报,GFS和EC有UTC18的数据，ENS_AVG暂不支持
    # start_date = pd.Timestamp('2022-05-18')
    # end_date = pd.Timestamp('2022-05-18')
    # compare_data = PWF.get_weather_from_diff_pub(sta_date=start_date,
    #                                              end_date=end_date,
    #                                              dn_offset=1,
    #                                              utc_list=[12, 18, 0])
    # compare_data.set_index('timestamp').plot()
    # print(compare_data)
    # compare_data.to_csv('test.csv')

    # 获取不同的D+N数据,注意当forecast_hour < 16时,publish_date会自动加一天
    # multi_dn_df = PWF.get_multi_dn_weather_forecast(sta_date=pd.Timestamp('2023-04-01'),
    #                                                 end_date=pd.Timestamp('2023-04-01'),
    #                                                 dn_list=list(range(1, 3)))
    #
    # 获取从pub_sta~pub_sta的发布数据
    multi_pub_df = PWF.get_all_pub_weather_forecast(pub_sta=pd.Timestamp('2023-09-04'),
                                                    pub_end=pd.Timestamp('2023-09-04'))

    print('Done')
    pass
