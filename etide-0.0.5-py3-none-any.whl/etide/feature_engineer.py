"""
包含常用的数据特征加工功能
"""
import logging
import pandas as pd
import numpy as np
import chinese_calendar as calendar


logger = logging.getLogger(__name__)


def get_holiday_info(x, return_str=False):
    """
    获取节假日信息
    :param x: 输入日期信息
    :param return_str: 返回字符串节假日信息
    :return: 0为非节假日,1~7都为节假日
    """
    holiday_list = ["New Year's Day", "Spring Festival", "Tomb-sweeping Day",
                    "Labour Day", "Dragon Boat Festival", "Mid-autumn Festival", "National Day"]
    holiday_dict = {name: i+1 for i, name in enumerate(holiday_list)}

    '内置判断函数'
    def get_name(date):
        """
        获取节假日名称
        """
        holiday_info = calendar.get_holiday_detail(date)
        if holiday_info[0] and holiday_info[1] in holiday_list:
            return holiday_info[1]
        else:
            return '0'

    date_names = np.array([get_name(d) for d in x])
    if not return_str:
        date_names = [holiday_dict[n] if n != '0' else 0 for n in date_names]

    return date_names


def get_period_window_statis(df, func, window):
    """
    获取同时刻指定窗口统计特征
    :param df: pd.DataFrame
    :param func: str, 统计函数名称, eg 'min', 'max', 'mean', 'std'
    :param window: int, 统计窗口大小
    :return:
    """
    feat_df = pd.DataFrame(df).copy()
    use_name = feat_df.columns.tolist()[0]
    feat_df['period'] = feat_df.index.hour * 4 + feat_df.index.minute // 15

    name = 'period_statis'
    feat_df[name] = feat_df.groupby('period').apply(
        lambda x: x[use_name].rolling(window, min_periods=1, center=True).agg(func)).sort_index(level=[1]).values
    feat_df[name] = feat_df[name].fillna(method='ffill')

    return feat_df[name].values


class BuiltinFeatures:
    """
    内置特征库
    格式为{'feature_function_name':feature_function}
    其中特征工程函数feature_function入参为一个series或者dataframe，输出数据类型为series或者单值
    """
    _intraday_stat_features = {
        'intraday_mean': lambda x: x.resample('D').mean().reindex(x.index).fillna(method='ffill'),
        'intraday_median': lambda x: x.resample('D').median().reindex(x.index).fillna(method='ffill'),
        'intraday_max': lambda x: x.resample('D').max().reindex(x.index).fillna(method='ffill'),
        'intraday_min': lambda x: x.resample('D').min().reindex(x.index).fillna(method='ffill'),
        'intraday_range': lambda x: (x.resample('D').max() - x.resample('D').min()).reindex(x.index).fillna(method='ffill'),
        'intraday_percentile_95': lambda x: x.resample('D').quantile(q=0.95).reindex(x.index).fillna(method='ffill')
    }

    _timeseries_basic_features = {
        'diff_1': lambda x: x.diff(1).fillna(0),
        'diff_2': lambda x: x.diff(2).fillna(0),
        'diff_4': lambda x: x.diff(4).fillna(0),
        'diff_8': lambda x: x.diff(8).fillna(0),
        'diff_16': lambda x: x.diff(16).fillna(0),
        'diff_24': lambda x: x.diff(24).fillna(0),
        'diff_96': lambda x: x.diff(96).fillna(0),
        'diff_192': lambda x: x.diff(192).fillna(0),
        'shift_24': lambda x: x.shift(24).fillna(0),
        'shift_96': lambda x: x.shift(96).fillna(0),
        'rolling_mean_4': lambda x: x.rolling(4, min_periods=1, center=True).mean(),
        'rolling_mean_8': lambda x: x.rolling(8, min_periods=1, center=True).mean(),
        'rolling_mean_16': lambda x: x.rolling(16, min_periods=1, center=True).mean(),
    }

    _interday_stat_features = {
        'interday_mean_diff': lambda x: x.resample('D').mean().diff(1).fillna(0).reindex(x.index).fillna(method='ffill'),
        'interday_max_diff': lambda x: x.resample('D').max().diff(1).fillna(0).reindex(x.index).fillna(method='ffill'),
        'interday_min_diff': lambda x: x.resample('D').min().diff(1).fillna(0).reindex(x.index).fillna(method='ffill'),

        'interday_cumsum': lambda x: x.resample('D').agg(lambda x: x.cumsum()),
        'interday_roll_sum_2': lambda x: x.resample('D').mean().rolling(2, min_periods=1, center=True).sum().reindex(x.index).fillna(method='ffill'),
        'period_roll_mean_3': lambda x: get_period_window_statis(x, 'mean', 3),

    }

    _time_features = {
        'time_index': lambda x: pd.Series((x.index.minute + x.index.hour * 60) / 15, index=x.index),
        'minute': lambda x: pd.Series(x.index.minute, index=x.index),
        'hour': lambda x: pd.Series(x.index.hour, index=x.index),
        'dayofweek': lambda x: pd.Series(x.index.dayofweek, index=x.index),
        'day': lambda x: pd.Series(x.index.day, index=x.index),
        'month': lambda x: pd.Series(x.index.month, index=x.index),
        'year': lambda x: pd.Series(x.index.year, index=x.index),
        'is_holiday': lambda x: pd.Series([int(calendar.is_holiday(i)) for i in x.index], index=x.index),
        'holiday_type': lambda x: pd.Series(get_holiday_info(x.index), index=x.index)
    }

    _default_feature_function_list = {
        **_intraday_stat_features,
        **_timeseries_basic_features,
        **_interday_stat_features,
        **_time_features,
    }

    _features_not_add_prefix = {
        **_time_features,
    }


class FeatureGenerator:
    """
    特征生成器，用于生成内置特征或者自定义特征，用法示例:
    feature_generator = FeatureGenerator()
    feature_generator.add_custom_feature_functions({'feature_function_name':feature_function})
    data_with_features = feature_generator.generate_features(data)
    """

    def __init__(self):
        """
        初始化特征工程列表
        """
        self.feature_function_list = BuiltinFeatures._default_feature_function_list
        self.features_not_add_prefix = BuiltinFeatures._features_not_add_prefix

    def get_feature_function_list(self):
        """
        返回特征工程列表
        :return:
        """
        return list(self.feature_function_list.keys())

    def add_custom_feature_functions(self, custom_feature_functions, if_not_add_prefix=False):
        """
        增加自定义特征工程
        :param custom_feature_functions: 自定义特征工程，数据类型为dict，例如：
                {'feature_function_name':feature_function}，其中特征工程函数feature_function接口格式与内置特征库一致
        :param if_not_add_prefix: 是否将自定义特征工程设置为不额外添加prefix，默认为False
        :return:
        """
        self.feature_function_list.update(custom_feature_functions)
        if if_not_add_prefix:
            self.features_not_add_prefix.update(custom_feature_functions)

    def generate_features(self, data, feature_functions=None, cols=None):
        """
        使用特征工程来生成特征
        :param data: 输入数据, 数据类型为dataframe或者series, index为时间戳类型，且每一天的时间戳从00:00:00开始
        :param feature_functions: 指定使用的特征工程列表，数据类型为list或者None，
                                如果使用默认生成的特征列名，则输入格式为['feature_function_name']，
                                如果要自定义生成的特征列名，则输入格式为[{'feature_function_name':'feature_name'}]，
                                如果为None则默认使用所有特征工程(包括内置特征和自定义特征)
        :param cols: 指定用哪些列进行特征工程，数据类型为str list或者None，
                    如果为str list且长度等于1，则表示配置的所有特征都作用在一列上，例如一列的最大值/最小值，此时特征工程函数feature_function入参为series
                    如果为str list且长度大于1，则表示配置的所有特征需要用多列数据计算得到，例如计算两列的和/差，此时特征工程函数feature_function入参为dataframe
                    如果输入数据data为series或者只有一列则可以为None
        :return: 在输入数据中添加特征列并返回，数据类型为dataframe
        """
        if feature_functions is None:
            feature_functions = self.get_feature_function_list()
        data = data.copy()
        if not isinstance(data, pd.DataFrame):
            data = pd.DataFrame(data)
        data.columns = [str(c) for c in data.columns]
        if len(data.columns) > 1:
            if cols is None:
                raise Exception('输入数据data列数大于1，cols不能为None')
            else:
                for col in cols:
                    if col not in data.columns:
                        raise Exception(f"输入数据data不包含'{col}'列")
                data_cols = data[cols]
        else:
            data_cols = data
        data_cols = data_cols.loc[data_cols.first_valid_index():data_cols.last_valid_index()]
        cols_str = '_'.join(data_cols.columns)
        data_cols = data_cols.squeeze()
        for feature_function in feature_functions:
            if isinstance(feature_function, dict):
                feature_function_name = list(feature_function.keys())[0]
                feature_name = feature_function[feature_function_name]
            else:
                feature_function_name = feature_function
                if feature_function in self.features_not_add_prefix:
                    feature_name = feature_function_name
                else:
                    feature_name = cols_str + '_' + feature_function_name
            if feature_function_name in self.feature_function_list:
                fe = self.feature_function_list[feature_function_name](data_cols)
                data[feature_name] = fe
            else:
                logger.warning(f'未识别特征工程:{feature_function_name}')
        return data
